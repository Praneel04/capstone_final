"""
Roboflow Detector Module
Uses Roboflow REST API for furniture detection in floor plans.
Works with any Python version (no inference-sdk dependency).
"""

import base64
import numpy as np
from pathlib import Path
from typing import List, Dict, Optional, Tuple, Union
import cv2
from PIL import Image
import requests

from .furniture_item import FurnitureItem


class RoboflowDetector:
    """
    Roboflow-based furniture detector using the REST API.
    
    Supports:
    - Roboflow hosted API
    - Instance segmentation models
    - Object detection models
    """
    
    def __init__(
        self,
        api_key: str = None,
        model_id: str = "furniture-ya4pe/1",
        api_url: str = "https://detect.roboflow.com",
        confidence_threshold: float = 0.25
    ):
        """
        Initialize the Roboflow detector.
        
        Args:
            api_key: Roboflow API key
            model_id: Model ID in format "project/version"
            api_url: Roboflow API URL
            confidence_threshold: Minimum confidence for detections
        """
        self.api_key = api_key
        self.model_id = model_id
        self.api_url = api_url
        self.confidence_threshold = confidence_threshold
        
        self._initialized = api_key is not None
        
        # Class name mapping (will be populated from results)
        self.class_names: Dict[int, str] = {}
        
        if api_key:
            print(f"Roboflow detector initialized: {model_id}")
    
    def set_api_key(self, api_key: str):
        """Set or update the API key."""
        self.api_key = api_key
        self._initialized = True
    
    def set_model(self, model_id: str):
        """Set the model ID."""
        self.model_id = model_id
    
    def detect(
        self,
        image: Union[str, Path, np.ndarray, Image.Image],
        extract_crops: bool = True
    ) -> List[FurnitureItem]:
        """
        Detect furniture in an image using Roboflow API.
        
        Args:
            image: Input image (path, numpy array, or PIL Image)
            extract_crops: Whether to extract furniture crops from the image
            
        Returns:
            List of FurnitureItem objects
        """
        if not self._initialized:
            raise RuntimeError(
                "Roboflow detector not initialized. "
                "Call set_api_key() first."
            )
        
        # Load and prepare image
        img_array = self._load_image(image)
        
        # Encode image to base64
        img_base64 = self._encode_image(img_array)
        
        # Make API request
        result = self._call_api(img_base64)
        
        # Parse results
        furniture_items = self._parse_results(result, img_array, extract_crops)
        
        return furniture_items
    
    def _load_image(self, image: Union[str, Path, np.ndarray, Image.Image]) -> np.ndarray:
        """Load image as numpy array (BGR format)."""
        if isinstance(image, (str, Path)):
            img = cv2.imread(str(image))
            if img is None:
                raise ValueError(f"Could not load image: {image}")
            return img
        elif isinstance(image, Image.Image):
            return cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
        elif isinstance(image, np.ndarray):
            return image
        else:
            raise TypeError(f"Unsupported image type: {type(image)}")
    
    def _encode_image(self, image: np.ndarray) -> str:
        """Encode image to base64 string."""
        _, buffer = cv2.imencode('.jpg', image)
        img_base64 = base64.b64encode(buffer).decode('utf-8')
        return img_base64
    
    def _call_api(self, img_base64: str) -> dict:
        """Call Roboflow API with base64 encoded image."""
        # Parse model_id to get project and version
        parts = self.model_id.split('/')
        if len(parts) == 2:
            project, version = parts
        else:
            project = self.model_id
            version = "1"
        
        # Build URL
        url = f"{self.api_url}/{project}/{version}"
        
        # Parameters
        params = {
            "api_key": self.api_key,
            "confidence": int(self.confidence_threshold * 100)
        }
        
        # Make request
        try:
            response = requests.post(
                url,
                params=params,
                data=img_base64,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=30
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            raise RuntimeError(f"API request failed: {e}")
    
    def _parse_results(
        self,
        result: dict,
        image: np.ndarray,
        extract_crops: bool
    ) -> List[FurnitureItem]:
        """Parse Roboflow API results into FurnitureItem objects."""
        
        furniture_items = []
        predictions = result.get('predictions', [])
        
        for idx, prediction in enumerate(predictions):
            # Get confidence
            confidence = prediction.get('confidence', 1.0)
            if confidence < self.confidence_threshold:
                continue
            
            # Get class name
            class_name = prediction.get('class', f'furniture_{idx}')
            
            # Get bounding box or polygon
            if 'points' in prediction:
                # Instance segmentation - get bbox from polygon
                item = self._create_item_from_polygon(
                    prediction, idx, class_name, confidence, image, extract_crops
                )
            else:
                # Object detection - use bbox directly
                item = self._create_item_from_bbox(
                    prediction, idx, class_name, confidence, image, extract_crops
                )
            
            if item:
                item.color = self._get_class_color(class_name)
                furniture_items.append(item)
        
        return furniture_items
    
    def _create_item_from_polygon(
        self,
        prediction: dict,
        idx: int,
        class_name: str,
        confidence: float,
        image: np.ndarray,
        extract_crops: bool
    ) -> Optional[FurnitureItem]:
        """Create FurnitureItem from polygon (segmentation) prediction."""
        
        points = prediction.get('points', [])
        if not points:
            return None
        
        # Get polygon points
        polygon = np.array(
            [[int(p['x']), int(p['y'])] for p in points],
            np.int32
        )
        
        # Get bounding box from polygon
        x, y, w, h = cv2.boundingRect(polygon)
        
        # Center coordinates
        cx = prediction.get('x', x + w / 2)
        cy = prediction.get('y', y + h / 2)
        
        item = FurnitureItem(
            id=idx,
            class_name=class_name,
            x=float(cx),
            y=float(cy),
            width=float(w),
            height=float(h),
            confidence=float(confidence),
            original_bbox=(float(x), float(y), float(x + w), float(y + h))
        )
        
        # Store polygon for segmentation mask
        item.polygon = polygon
        
        # Extract crop with transparency
        if extract_crops:
            item.image = self._extract_segmentation_crop(image, polygon)
        
        return item
    
    def _create_item_from_bbox(
        self,
        prediction: dict,
        idx: int,
        class_name: str,
        confidence: float,
        image: np.ndarray,
        extract_crops: bool
    ) -> Optional[FurnitureItem]:
        """Create FurnitureItem from bounding box prediction."""
        
        # Get center and dimensions
        cx = prediction.get('x', 0)
        cy = prediction.get('y', 0)
        w = prediction.get('width', 0)
        h = prediction.get('height', 0)
        
        if w <= 0 or h <= 0:
            return None
        
        # Calculate bbox corners
        x1 = cx - w / 2
        y1 = cy - h / 2
        x2 = cx + w / 2
        y2 = cy + h / 2
        
        item = FurnitureItem(
            id=idx,
            class_name=class_name,
            x=float(cx),
            y=float(cy),
            width=float(w),
            height=float(h),
            confidence=float(confidence),
            original_bbox=(float(x1), float(y1), float(x2), float(y2))
        )
        
        # Extract crop
        if extract_crops:
            item.image = self._extract_bbox_crop(image, x1, y1, x2, y2)
        
        return item
    
    def _extract_segmentation_crop(
        self,
        image: np.ndarray,
        polygon: np.ndarray
    ) -> np.ndarray:
        """Extract furniture crop with transparency from segmentation mask."""
        
        # Create mask from polygon
        mask = np.zeros(image.shape[:2], dtype=np.uint8)
        cv2.fillPoly(mask, [polygon], 255)
        
        # Apply mask to image
        masked = cv2.bitwise_and(image, image, mask=mask)
        
        # Get bounding rect
        x, y, w, h = cv2.boundingRect(polygon)
        
        # Crop region
        cropped_rgb = masked[y:y+h, x:x+w]
        cropped_mask = mask[y:y+h, x:x+w]
        
        # Create RGBA image with transparency
        if len(cropped_rgb.shape) == 3:
            b, g, r = cv2.split(cropped_rgb)
            rgba = cv2.merge((b, g, r, cropped_mask))
        else:
            rgba = cv2.merge((cropped_rgb, cropped_rgb, cropped_rgb, cropped_mask))
        
        return rgba
    
    def _extract_bbox_crop(
        self,
        image: np.ndarray,
        x1: float, y1: float, x2: float, y2: float
    ) -> np.ndarray:
        """Extract furniture crop from bounding box."""
        
        # Clamp to image bounds
        h, w = image.shape[:2]
        x1 = max(0, int(x1))
        y1 = max(0, int(y1))
        x2 = min(w, int(x2))
        y2 = min(h, int(y2))
        
        if x2 <= x1 or y2 <= y1:
            return np.zeros((1, 1, 3), dtype=np.uint8)
        
        return image[y1:y2, x1:x2].copy()
    
    def _get_class_color(self, class_name: str) -> Tuple[int, int, int]:
        """Get a consistent color for each class."""
        color_map = {
            'bed': (0, 255, 0),
            'sofa': (255, 165, 0),
            'lsofa': (255, 140, 0),
            'l-sofa': (255, 140, 0),
            'chair': (0, 191, 255),
            'table': (255, 0, 255),
            'desk': (148, 0, 211),
            'cabinet': (139, 69, 19),
            'wardrobe': (160, 82, 45),
            'tv': (70, 130, 180),
            'lamp': (255, 255, 0),
            'plant': (0, 128, 0),
            'rug': (255, 182, 193),
            'bathtub': (0, 255, 255),
            'toilet': (192, 192, 192),
            'sink': (173, 216, 230),
            'stove': (255, 0, 0),
            'refrigerator': (240, 248, 255),
            'dining_table': (218, 165, 32),
            'dining-table': (218, 165, 32),
            'kitchen': (255, 99, 71),
            'commode': (210, 180, 140),
            'study': (75, 0, 130),
            'door': (128, 128, 128),
            'window': (135, 206, 235),
            'wall': (169, 169, 169),
        }
        
        return color_map.get(class_name.lower(), (0, 255, 0))
    
    def set_thresholds(self, confidence: float = None, iou: float = None):
        """Update detection thresholds."""
        if confidence is not None:
            self.confidence_threshold = confidence
    
    def get_class_names(self) -> Dict[int, str]:
        """Get the class names dictionary."""
        return self.class_names


class MockRoboflowDetector(RoboflowDetector):
    """
    Mock Roboflow detector for testing without API access.
    Generates random furniture detections.
    """
    
    def __init__(self, **kwargs):
        # Don't call parent init to avoid API requirements
        self.confidence_threshold = kwargs.get('confidence_threshold', 0.25)
        self.class_names = {}
        self._initialized = True
    
    def detect(
        self,
        image: Union[str, Path, np.ndarray, Image.Image],
        extract_crops: bool = True
    ) -> List[FurnitureItem]:
        """Generate mock detections for testing."""
        
        # Load image
        if isinstance(image, (str, Path)):
            img_array = cv2.imread(str(image))
        elif isinstance(image, Image.Image):
            img_array = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
        else:
            img_array = image
        
        if img_array is None:
            return []
        
        h, w = img_array.shape[:2]
        
        # Generate mock furniture
        mock_furniture = [
            ('bed', 0.25, 0.7, 0.12, 0.10),
            ('sofa', 0.35, 0.25, 0.15, 0.06),
            ('table', 0.55, 0.45, 0.08, 0.08),
            ('chair', 0.65, 0.55, 0.04, 0.04),
            ('bathtub', 0.75, 0.35, 0.10, 0.06),
            ('sink', 0.80, 0.40, 0.04, 0.04),
            ('stove', 0.30, 0.35, 0.06, 0.06),
        ]
        
        furniture_items = []
        
        for i, (cls, cx_pct, cy_pct, w_pct, h_pct) in enumerate(mock_furniture):
            cx = cx_pct * w
            cy = cy_pct * h
            fw = w_pct * w
            fh = h_pct * h
            
            item = FurnitureItem(
                id=i,
                class_name=cls,
                x=cx,
                y=cy,
                width=fw,
                height=fh,
                confidence=0.85 + np.random.random() * 0.1,
                original_bbox=(cx - fw/2, cy - fh/2, cx + fw/2, cy + fh/2)
            )
            
            if extract_crops:
                x1, y1, x2, y2 = item.original_bbox
                item.image = self._extract_bbox_crop(img_array, x1, y1, x2, y2)
            
            item.color = self._get_class_color(cls)
            furniture_items.append(item)
        
        return furniture_items
    
    def _extract_bbox_crop(self, image, x1, y1, x2, y2):
        h, w = image.shape[:2]
        x1 = max(0, int(x1))
        y1 = max(0, int(y1))
        x2 = min(w, int(x2))
        y2 = min(h, int(y2))
        
        if x2 <= x1 or y2 <= y1:
            return np.zeros((1, 1, 3), dtype=np.uint8)
        
        return image[y1:y2, x1:x2].copy()
    
    def _get_class_color(self, class_name):
        color_map = {
            'bed': (0, 255, 0),
            'sofa': (255, 165, 0),
            'chair': (0, 191, 255),
            'table': (255, 0, 255),
            'bathtub': (0, 255, 255),
            'sink': (173, 216, 230),
            'stove': (255, 0, 0),
        }
        return color_map.get(class_name.lower(), (0, 255, 0))
