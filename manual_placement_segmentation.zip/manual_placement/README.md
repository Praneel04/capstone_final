# Floor Plan Manual Correction App

An interactive application for manually correcting furniture placement in LoRA-generated floor plans. Uses Roboflow API for furniture detection and provides a drag-and-drop interface for corrections.

## Features

- **Roboflow API Integration**: Automatically detect furniture using Roboflow's hosted inference
- **Instance Segmentation Support**: Extract furniture with precise masks (not just bounding boxes)
- **Interactive Drag-and-Drop**: Move furniture by dragging with the mouse
- **Rotation Controls**: Rotate furniture using mouse wheel, rotation handles, or keyboard
- **Real-time Preview**: See changes instantly as you modify furniture placement
- **Properties Panel**: Fine-tune position, size, and rotation with precise controls
- **Export Options**: Save corrected floor plans or export layouts as JSON

## Installation

1. Clone or download this repository
2. Install dependencies:

```bash
pip install -r requirements.txt
```

## Usage

### Running the App

```bash
python main.py
```

### Basic Workflow

1. **Open Floor Plan**: File → Open Floor Plan (Ctrl+O)
2. **Detect Furniture**: Detection → Detect Furniture (Ctrl+D)
3. **Adjust Furniture**: 
   - **Drag** to move furniture
   - **Mouse wheel** to rotate
   - Use **Properties Panel** for precise adjustments
4. **Save Result**: File → Save Result (Ctrl+S)

### Configuring Roboflow API

The app comes pre-configured with a default Roboflow model. To use your own:

1. Go to **Model → Roboflow API → Configure API Key**
2. Enter your Roboflow API key
3. Go to **Model → Roboflow API → Set Model ID**
4. Enter your model ID (format: `project/version`, e.g., `furniture-ya4pe/1`)
2. Select your `.pt`, `.onnx`, or `.engine` model file
3. The model will be used for subsequent detections

#### Plug-and-Play Model Interface

You can also programmatically set a custom model:

```python
from detection import YOLODetector

# Option 1: Load from file
detector = YOLODetector(model_path="path/to/your/model.pt")

# Option 2: Use existing model object
from ultralytics import YOLO
my_model = YOLO("path/to/model.pt")
detector = YOLODetector()
detector.set_model(my_model, class_names={0: 'bed', 1: 'sofa', ...})

# Option 3: Custom callable
def my_detector(image):
    # Your detection logic
    return [(x1, y1, x2, y2, confidence, class_id), ...]

detector = YOLODetector()
detector.set_model(my_detector)
```

### Controls

| Action | Control |
|--------|---------|
| Open file | Ctrl+O |
| Save result | Ctrl+S |
| Detect furniture | Ctrl+D |
| Fit to view | Ctrl+0 |
| Move selected | Arrow keys |
| Fine movement | Shift + Arrow keys |
| Rotate (small) | R / E keys |
| Rotate (wheel) | Mouse wheel |
| Zoom | Ctrl + Mouse wheel |
| Pan | Middle mouse button |
| Delete selected | Delete key |

### Detection Settings

- **Confidence Threshold**: Adjust in toolbar or Detection menu (default: 25%)
- Higher values = fewer false positives, might miss some furniture
- Lower values = more detections, might include noise

## Project Structure

```
manual_placement/
├── main.py                 # Application entry point
├── requirements.txt        # Python dependencies
├── README.md              # This file
├── detection/
│   ├── __init__.py
│   ├── yolo_detector.py   # YOLO detection wrapper
│   └── furniture_item.py  # Furniture data class
├── ui/
│   ├── __init__.py
│   ├── main_window.py     # Main application window
│   ├── floor_plan_canvas.py # Interactive canvas
│   ├── properties_panel.py  # Property editor
│   └── furniture_widget.py  # Catalog widget
└── utils/
    ├── __init__.py
    └── image_utils.py     # Image utilities
```

## Supported YOLO Models

- **Ultralytics YOLO**: YOLOv5, YOLOv8, YOLOv11
- **Custom Models**: Any model with compatible interface

### Custom Model Requirements

Your model should have one of these interfaces:

```python
# Callable
model(image) -> List[Tuple[x1, y1, x2, y2, confidence, class_id]]

# Or method-based
model.predict(image) -> List[...]
model.detect(image) -> List[...]
```

## Class Names

Default supported furniture classes:

- bed, sofa, Lsofa, chair, table, desk
- cabinet, wardrobe, tv, lamp, plant, rug
- bathtub, toilet, sink, stove
- refrigerator, dining_table, kitchen
- commode, study

Customize class names when loading your model:

```python
custom_classes = {
    0: 'my_furniture_1',
    1: 'my_furniture_2',
    # ...
}
detector = YOLODetector(model_path="model.pt", class_names=custom_classes)
```

## Export Format

JSON layout export format:

```json
{
  "image_path": "path/to/floor_plan.png",
  "items": [
    {
      "id": 0,
      "class_name": "bed",
      "x": 150.5,
      "y": 200.3,
      "width": 80.0,
      "height": 120.0,
      "angle": 45.0,
      "confidence": 0.92,
      "original_bbox": [110.5, 140.3, 190.5, 260.3]
    }
  ]
}
```

## Tips

1. **Use Mock Detector for Testing**: The app includes a mock detector that generates sample furniture without needing a real YOLO model.

2. **Furniture Icons**: Place PNG icons in a `catalog/` folder to use custom furniture icons. Name them by class (e.g., `bed.png`, `sofa.png`).

3. **Batch Processing**: For multiple floor plans, you can use the detection and utility modules directly in Python scripts.

## Troubleshooting

### "Could not load model"
- Ensure Ultralytics is installed: `pip install ultralytics`
- Check model file path and format

### "No detections found"
- Lower the confidence threshold
- Ensure the model was trained on similar floor plan images

### UI not responding
- Large images may take time to process
- Try reducing image size before loading

## License

MIT License - Feel free to use and modify for your projects.
