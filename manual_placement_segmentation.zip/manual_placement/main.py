"""
Floor Plan Manual Correction App
Allows manual drag-and-drop correction of furniture placement on LoRA-generated floor plans.
Uses YOLO for furniture detection and provides real-time preview.
"""

import sys
from PyQt5.QtWidgets import QApplication
from ui.main_window import MainWindow


def main():
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    
    window = MainWindow()
    window.show()
    
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
