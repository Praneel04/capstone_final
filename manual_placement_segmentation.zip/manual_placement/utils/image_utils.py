"""
Utility functions for the floor plan correction app.
"""

import cv2
import numpy as np
from typing import Tuple, List
from pathlib import Path


def rotate_image(image: np.ndarray, angle: float, center: Tuple[int, int] = None) -> np.ndarray:
    """
    Rotate an image by the given angle.
    
    Args:
        image: Input image
        angle: Rotation angle in degrees
        center: Rotation center (defaults to image center)
        
    Returns:
        Rotated image
    """
    h, w = image.shape[:2]
    
    if center is None:
        center = (w // 2, h // 2)
    
    # Get rotation matrix
    rotation_matrix = cv2.getRotationMatrix2D(center, angle, 1.0)
    
    # Calculate new image size
    cos = abs(rotation_matrix[0, 0])
    sin = abs(rotation_matrix[0, 1])
    new_w = int(h * sin + w * cos)
    new_h = int(h * cos + w * sin)
    
    # Adjust rotation matrix
    rotation_matrix[0, 2] += (new_w - w) / 2
    rotation_matrix[1, 2] += (new_h - h) / 2
    
    # Apply rotation
    rotated = cv2.warpAffine(
        image, rotation_matrix, (new_w, new_h),
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=(0, 0, 0, 0) if image.shape[-1] == 4 else (0, 0, 0)
    )
    
    return rotated


def blend_images(background: np.ndarray, foreground: np.ndarray, 
                 x: int, y: int, alpha: float = 1.0) -> np.ndarray:
    """
    Blend foreground image onto background at the specified position.
    
    Args:
        background: Background image
        foreground: Foreground image (can have alpha channel)
        x: X position for top-left corner
        y: Y position for top-left corner
        alpha: Overall opacity (0-1)
        
    Returns:
        Blended image
    """
    result = background.copy()
    
    fg_h, fg_w = foreground.shape[:2]
    bg_h, bg_w = background.shape[:2]
    
    # Calculate valid regions
    x1 = max(0, x)
    y1 = max(0, y)
    x2 = min(bg_w, x + fg_w)
    y2 = min(bg_h, y + fg_h)
    
    fx1 = max(0, -x)
    fy1 = max(0, -y)
    fx2 = fx1 + (x2 - x1)
    fy2 = fy1 + (y2 - y1)
    
    if x2 <= x1 or y2 <= y1:
        return result
    
    # Get regions
    fg_region = foreground[fy1:fy2, fx1:fx2]
    bg_region = result[y1:y2, x1:x2]
    
    # Blend based on alpha channel
    if foreground.shape[-1] == 4:
        fg_alpha = (fg_region[:, :, 3:4] / 255.0) * alpha
        fg_rgb = fg_region[:, :, :3]
        
        blended = (fg_rgb * fg_alpha + bg_region * (1 - fg_alpha)).astype(np.uint8)
        result[y1:y2, x1:x2] = blended
    else:
        if alpha < 1.0:
            blended = cv2.addWeighted(fg_region, alpha, bg_region, 1 - alpha, 0)
            result[y1:y2, x1:x2] = blended
        else:
            result[y1:y2, x1:x2] = fg_region
    
    return result


def create_icon_from_crop(crop: np.ndarray, size: Tuple[int, int] = (64, 64)) -> np.ndarray:
    """
    Create a furniture icon from a cropped image.
    
    Args:
        crop: Cropped furniture image
        size: Target icon size
        
    Returns:
        Icon image with alpha channel
    """
    # Resize
    icon = cv2.resize(crop, size, interpolation=cv2.INTER_AREA)
    
    # Add alpha channel if needed
    if icon.shape[-1] != 4:
        # Simple background removal based on color similarity to edges
        gray = cv2.cvtColor(icon, cv2.COLOR_BGR2GRAY)
        
        # Use edge detection to create mask
        edges = cv2.Canny(gray, 50, 150)
        kernel = np.ones((3, 3), np.uint8)
        mask = cv2.dilate(edges, kernel, iterations=2)
        
        # Fill interior
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if contours:
            cv2.drawContours(mask, contours, -1, 255, -1)
        
        # Create BGRA image
        icon_bgra = np.dstack([icon, mask])
        return icon_bgra
    
    return icon


def calculate_iou(box1: Tuple[float, float, float, float], 
                  box2: Tuple[float, float, float, float]) -> float:
    """
    Calculate Intersection over Union of two bounding boxes.
    
    Args:
        box1: (x1, y1, x2, y2)
        box2: (x1, y1, x2, y2)
        
    Returns:
        IoU value (0-1)
    """
    x1 = max(box1[0], box2[0])
    y1 = max(box1[1], box2[1])
    x2 = min(box1[2], box2[2])
    y2 = min(box1[3], box2[3])
    
    if x2 <= x1 or y2 <= y1:
        return 0.0
    
    intersection = (x2 - x1) * (y2 - y1)
    
    area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
    area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
    
    union = area1 + area2 - intersection
    
    return intersection / union if union > 0 else 0.0


def load_furniture_catalog(catalog_dir: str) -> dict:
    """
    Load furniture icons from a catalog directory.
    
    Args:
        catalog_dir: Path to directory containing furniture icons
        
    Returns:
        Dictionary mapping class names to icon images
    """
    catalog = {}
    catalog_path = Path(catalog_dir)
    
    if not catalog_path.exists():
        return catalog
    
    for icon_file in catalog_path.glob('*.png'):
        class_name = icon_file.stem.lower()
        icon = cv2.imread(str(icon_file), cv2.IMREAD_UNCHANGED)
        if icon is not None:
            catalog[class_name] = icon
    
    # Also check for jpg files
    for icon_file in catalog_path.glob('*.jpg'):
        class_name = icon_file.stem.lower()
        if class_name not in catalog:
            icon = cv2.imread(str(icon_file))
            if icon is not None:
                catalog[class_name] = icon
    
    return catalog


def apply_furniture_to_floorplan(floorplan: np.ndarray, 
                                  furniture_items: List,
                                  icon_catalog: dict = None) -> np.ndarray:
    """
    Apply furniture items to a floor plan image.
    
    Args:
        floorplan: Original floor plan image
        furniture_items: List of FurnitureItem objects
        icon_catalog: Optional dictionary of furniture icons
        
    Returns:
        Floor plan with furniture placed
    """
    result = floorplan.copy()
    
    for item in furniture_items:
        # Get the image to use
        if icon_catalog and item.class_name.lower() in icon_catalog:
            furniture_img = icon_catalog[item.class_name.lower()]
        elif item.icon is not None:
            furniture_img = item.icon
        elif item.image is not None:
            furniture_img = item.image
        else:
            continue
        
        # Resize to match item dimensions
        target_w = int(item.width)
        target_h = int(item.height)
        
        if target_w <= 0 or target_h <= 0:
            continue
        
        resized = cv2.resize(furniture_img, (target_w, target_h))
        
        # Rotate if needed
        if item.angle != 0:
            resized = rotate_image(resized, -item.angle)
        
        # Calculate position (center-based)
        h, w = resized.shape[:2]
        x = int(item.x - w / 2)
        y = int(item.y - h / 2)
        
        # Blend onto result
        result = blend_images(result, resized, x, y)
    
    return result
