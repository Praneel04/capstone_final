"""
YOLO Detector Module
Plug-and-play interface for custom YOLO models to detect furniture in floor plans.
"""

import numpy as np
from pathlib import Path
from typing import List, Dict, Optional, Tuple, Union
import cv2
from PIL import Image

from .furniture_item import FurnitureItem


class YOLODetector:
    """
    YOLO-based furniture detector with plug-and-play model support.
    
    Supports:
    - Ultralytics YOLO (YOLOv5, YOLOv8, YOLOv11)
    - Custom YOLO implementations via callable interface
    """
    
    # Default class names for furniture detection
    DEFAULT_CLASS_NAMES = {
        0: 'bed',
        1: 'sofa',
        2: 'chair',
        3: 'table',
        4: 'desk',
        5: 'cabinet',
        6: 'wardrobe',
        7: 'tv',
        8: 'lamp',
        9: 'plant',
        10: 'rug',
        11: 'bathtub',
        12: 'toilet',
        13: 'sink',
        14: 'stove',
        15: 'refrigerator',
        16: 'dining_table',
        17: 'kitchen',
        18: 'Lsofa',
        19: 'commode',
        20: 'study'
    }
    
    def __init__(
        self,
        model_path: Optional[str] = None,
        model: Optional[object] = None,
        class_names: Optional[Dict[int, str]] = None,
        confidence_threshold: float = 0.25,
        iou_threshold: float = 0.45,
        device: str = 'auto'
    ):
        """
        Initialize the YOLO detector.
        
        Args:
            model_path: Path to YOLO model weights (.pt, .onnx, etc.)
            model: Pre-loaded YOLO model object (for plug-and-play)
            class_names: Dictionary mapping class IDs to names
            confidence_threshold: Minimum confidence for detections
            iou_threshold: IoU threshold for NMS
            device: Device to run inference on ('auto', 'cpu', 'cuda', 'mps')
        """
        self.model_path = model_path
        self.model = model
        self.class_names = class_names or self.DEFAULT_CLASS_NAMES
        self.confidence_threshold = confidence_threshold
        self.iou_threshold = iou_threshold
        self.device = device
        
        self._model_loaded = False
        self._ultralytics_model = None
        
        if model is not None:
            self._model_loaded = True
        elif model_path is not None:
            self.load_model(model_path)
    
    def load_model(self, model_path: str):
        """
        Load a YOLO model from file.
        
        Args:
            model_path: Path to the model weights
        """
        self.model_path = model_path
        
        try:
            # Try loading with ultralytics
            from ultralytics import YOLO
            
            self._ultralytics_model = YOLO(model_path)
            
            # Update class names from model if available
            if hasattr(self._ultralytics_model, 'names'):
                self.class_names = self._ultralytics_model.names
            
            self._model_loaded = True
            print(f"Model loaded successfully: {model_path}")
            
        except ImportError:
            print("Ultralytics not installed. Please install with: pip install ultralytics")
            raise
        except Exception as e:
            print(f"Error loading model: {e}")
            raise
    
    def set_model(self, model: object, class_names: Optional[Dict[int, str]] = None):
        """
        Set a pre-loaded model for plug-and-play usage.
        
        Args:
            model: YOLO model object with a predict/inference method
            class_names: Optional class names dictionary
        """
        self.model = model
        if class_names:
            self.class_names = class_names
        self._model_loaded = True
    
    def detect(
        self,
        image: Union[str, Path, np.ndarray, Image.Image],
        extract_crops: bool = True
    ) -> List[FurnitureItem]:
        """
        Detect furniture in an image.
        
        Args:
            image: Input image (path, numpy array, or PIL Image)
            extract_crops: Whether to extract furniture crops from the image
            
        Returns:
            List of FurnitureItem objects
        """
        if not self._model_loaded:
            raise RuntimeError("No model loaded. Call load_model() or set_model() first.")
        
        # Convert image to numpy array
        img_array = self._load_image(image)
        
        # Run detection
        if self._ultralytics_model is not None:
            detections = self._detect_ultralytics(img_array)
        elif self.model is not None:
            detections = self._detect_custom(img_array)
        else:
            raise RuntimeError("No model available for detection.")
        
        # Convert to FurnitureItem objects
        furniture_items = []
        for i, det in enumerate(detections):
            item = FurnitureItem.from_yolo_detection(det, self.class_names, item_id=i)
            
            # Extract crop if requested
            if extract_crops:
                item.image = self._extract_crop(img_array, item)
            
            # Assign a color based on class
            item.color = self._get_class_color(item.class_name)
            
            furniture_items.append(item)
        
        return furniture_items
    
    def _load_image(self, image: Union[str, Path, np.ndarray, Image.Image]) -> np.ndarray:
        """Load and convert image to numpy array (BGR format)."""
        if isinstance(image, (str, Path)):
            img = cv2.imread(str(image))
            if img is None:
                raise ValueError(f"Could not load image: {image}")
            return img
        elif isinstance(image, Image.Image):
            # Convert PIL to numpy (RGB to BGR)
            return cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
        elif isinstance(image, np.ndarray):
            return image
        else:
            raise TypeError(f"Unsupported image type: {type(image)}")
    
    def _detect_ultralytics(self, image: np.ndarray) -> List[Tuple]:
        """Run detection using Ultralytics YOLO."""
        results = self._ultralytics_model(
            image,
            conf=self.confidence_threshold,
            iou=self.iou_threshold,
            verbose=False
        )
        
        detections = []
        for result in results:
            boxes = result.boxes
            if boxes is not None:
                for box in boxes:
                    x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
                    conf = box.conf[0].cpu().numpy()
                    cls = box.cls[0].cpu().numpy()
                    detections.append((x1, y1, x2, y2, conf, cls))
        
        return detections
    
    def _detect_custom(self, image: np.ndarray) -> List[Tuple]:
        """
        Run detection using a custom model.
        
        The custom model should have one of these interfaces:
        1. model(image) -> list of [x1, y1, x2, y2, conf, class_id]
        2. model.predict(image) -> list of [x1, y1, x2, y2, conf, class_id]
        3. model.detect(image) -> list of [x1, y1, x2, y2, conf, class_id]
        """
        if callable(self.model):
            results = self.model(image)
        elif hasattr(self.model, 'predict'):
            results = self.model.predict(image)
        elif hasattr(self.model, 'detect'):
            results = self.model.detect(image)
        elif hasattr(self.model, '__call__'):
            results = self.model(image)
        else:
            raise RuntimeError("Custom model must be callable or have predict/detect method")
        
        # Convert results to standard format
        detections = []
        for det in results:
            if len(det) >= 6:
                detections.append(tuple(det[:6]))
            elif len(det) >= 5:
                # Assume last element is class, add default confidence
                detections.append((*det[:4], det[4], 0))
        
        return detections
    
    def _extract_crop(self, image: np.ndarray, item: FurnitureItem) -> np.ndarray:
        """Extract furniture crop from image."""
        x1, y1, x2, y2 = item.original_bbox
        x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
        
        # Clamp to image bounds
        h, w = image.shape[:2]
        x1 = max(0, x1)
        y1 = max(0, y1)
        x2 = min(w, x2)
        y2 = min(h, y2)
        
        crop = image[y1:y2, x1:x2].copy()
        return crop
    
    def _get_class_color(self, class_name: str) -> Tuple[int, int, int]:
        """Get a consistent color for each class."""
        # Color palette for different furniture types
        color_map = {
            'bed': (0, 255, 0),       # Green
            'sofa': (255, 165, 0),    # Orange
            'Lsofa': (255, 140, 0),   # Dark Orange
            'chair': (0, 191, 255),   # Deep Sky Blue
            'table': (255, 0, 255),   # Magenta
            'desk': (148, 0, 211),    # Dark Violet
            'cabinet': (139, 69, 19), # Saddle Brown
            'wardrobe': (160, 82, 45),# Sienna
            'tv': (70, 130, 180),     # Steel Blue
            'lamp': (255, 255, 0),    # Yellow
            'plant': (0, 128, 0),     # Dark Green
            'rug': (255, 182, 193),   # Light Pink
            'bathtub': (0, 255, 255), # Cyan
            'toilet': (192, 192, 192),# Silver
            'sink': (173, 216, 230),  # Light Blue
            'stove': (255, 0, 0),     # Red
            'refrigerator': (240, 248, 255), # Alice Blue
            'dining_table': (218, 165, 32),  # Goldenrod
            'kitchen': (255, 99, 71), # Tomato
            'commode': (210, 180, 140),# Tan
            'study': (75, 0, 130),    # Indigo
        }
        
        return color_map.get(class_name.lower(), (0, 255, 0))
    
    def set_thresholds(self, confidence: float = None, iou: float = None):
        """Update detection thresholds."""
        if confidence is not None:
            self.confidence_threshold = confidence
        if iou is not None:
            self.iou_threshold = iou
    
    def get_class_names(self) -> Dict[int, str]:
        """Get the class names dictionary."""
        return self.class_names
    
    def set_class_names(self, class_names: Dict[int, str]):
        """Set custom class names."""
        self.class_names = class_names


class MockYOLODetector(YOLODetector):
    """
    Mock YOLO detector for testing without a real model.
    Generates random furniture detections.
    """
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._model_loaded = True
    
    def detect(
        self,
        image: Union[str, Path, np.ndarray, Image.Image],
        extract_crops: bool = True
    ) -> List[FurnitureItem]:
        """Generate mock detections for testing."""
        img_array = self._load_image(image)
        h, w = img_array.shape[:2]
        
        # Generate some random furniture items
        mock_furniture = [
            ('bed', 0.2, 0.7, 0.15, 0.12),
            ('sofa', 0.3, 0.3, 0.18, 0.08),
            ('table', 0.6, 0.5, 0.1, 0.1),
            ('chair', 0.7, 0.6, 0.05, 0.05),
            ('bathtub', 0.5, 0.4, 0.12, 0.08),
        ]
        
        furniture_items = []
        for i, (cls, cx, cy, fw, fh) in enumerate(mock_furniture):
            item = FurnitureItem(
                id=i,
                class_name=cls,
                x=cx * w,
                y=cy * h,
                width=fw * w,
                height=fh * h,
                confidence=0.85 + np.random.random() * 0.1
            )
            
            if extract_crops:
                item.image = self._extract_crop(img_array, item)
            
            item.color = self._get_class_color(cls)
            furniture_items.append(item)
        
        return furniture_items
