"""
Furniture Item Data Class
Represents a detected furniture item with position, rotation, and metadata.
"""

from dataclasses import dataclass, field
from typing import Optional, Tuple
import numpy as np
from PIL import Image
import cv2


@dataclass
class FurnitureItem:
    """Represents a furniture item detected in the floor plan."""
    
    # Unique identifier
    id: int
    
    # Class/type of furniture (e.g., 'bed', 'sofa', 'table')
    class_name: str
    
    # Position (center x, center y) in image coordinates
    x: float
    y: float
    
    # Bounding box dimensions
    width: float
    height: float
    
    # Rotation angle in degrees (0-360)
    angle: float = 0.0
    
    # Confidence score from detection
    confidence: float = 1.0
    
    # Original bounding box [x1, y1, x2, y2]
    original_bbox: Tuple[float, float, float, float] = field(default_factory=tuple)
    
    # Extracted furniture image (cropped from floor plan)
    image: Optional[np.ndarray] = None
    
    # Custom icon image (from catalog)
    icon: Optional[np.ndarray] = None
    
    # Whether this item is currently selected
    selected: bool = False
    
    # Color for visualization
    color: Tuple[int, int, int] = (0, 255, 0)
    
    # Segmentation polygon (for instance segmentation)
    polygon: Optional[np.ndarray] = None
    
    def __post_init__(self):
        """Initialize computed properties."""
        if not self.original_bbox:
            # Compute bbox from center and dimensions
            x1 = self.x - self.width / 2
            y1 = self.y - self.height / 2
            x2 = self.x + self.width / 2
            y2 = self.y + self.height / 2
            self.original_bbox = (x1, y1, x2, y2)
    
    @property
    def bbox(self) -> Tuple[float, float, float, float]:
        """Get current bounding box based on position and dimensions."""
        x1 = self.x - self.width / 2
        y1 = self.y - self.height / 2
        x2 = self.x + self.width / 2
        y2 = self.y + self.height / 2
        return (x1, y1, x2, y2)
    
    @property
    def center(self) -> Tuple[float, float]:
        """Get center point."""
        return (self.x, self.y)
    
    def move_to(self, x: float, y: float):
        """Move furniture to new position."""
        self.x = x
        self.y = y
    
    def move_by(self, dx: float, dy: float):
        """Move furniture by offset."""
        self.x += dx
        self.y += dy
    
    def rotate_to(self, angle: float):
        """Set rotation angle (in degrees)."""
        self.angle = angle % 360
    
    def rotate_by(self, delta_angle: float):
        """Rotate by delta angle (in degrees)."""
        self.angle = (self.angle + delta_angle) % 360
    
    def resize(self, width: float, height: float):
        """Resize the furniture item."""
        self.width = width
        self.height = height
    
    def scale(self, factor: float):
        """Scale the furniture item uniformly."""
        self.width *= factor
        self.height *= factor
    
    def contains_point(self, px: float, py: float) -> bool:
        """Check if a point is inside the furniture polygon or bounding box."""
        # Use polygon if available for precise hit testing
        if self.polygon is not None:
            # Translate polygon to current position
            translated = self.get_current_polygon()
            if translated is not None:
                import cv2
                result = cv2.pointPolygonTest(translated, (px, py), False)
                return result >= 0
        
        # Fallback to bounding box
        x1, y1, x2, y2 = self.bbox
        return x1 <= px <= x2 and y1 <= py <= y2
    
    def get_current_polygon(self) -> Optional[np.ndarray]:
        """Get the polygon translated to the current position."""
        if self.polygon is None:
            return None
        
        # Calculate offset from original position
        orig_x1, orig_y1, orig_x2, orig_y2 = self.original_bbox
        orig_cx = (orig_x1 + orig_x2) / 2
        orig_cy = (orig_y1 + orig_y2) / 2
        
        dx = self.x - orig_cx
        dy = self.y - orig_cy
        
        # Translate polygon
        translated = self.polygon.copy()
        translated[:, 0] = translated[:, 0] + dx
        translated[:, 1] = translated[:, 1] + dy
        
        return translated.astype(np.int32)
    
    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            'id': self.id,
            'class_name': self.class_name,
            'x': self.x,
            'y': self.y,
            'width': self.width,
            'height': self.height,
            'angle': self.angle,
            'confidence': self.confidence,
            'original_bbox': self.original_bbox
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'FurnitureItem':
        """Create from dictionary."""
        return cls(
            id=data['id'],
            class_name=data['class_name'],
            x=data['x'],
            y=data['y'],
            width=data['width'],
            height=data['height'],
            angle=data.get('angle', 0.0),
            confidence=data.get('confidence', 1.0),
            original_bbox=tuple(data.get('original_bbox', ()))
        )
    
    @classmethod
    def from_yolo_detection(cls, detection, class_names: dict, item_id: int) -> 'FurnitureItem':
        """
        Create from YOLO detection result.
        
        Args:
            detection: YOLO detection (x1, y1, x2, y2, confidence, class_id)
            class_names: Dictionary mapping class_id to class_name
            item_id: Unique identifier for this item
        """
        x1, y1, x2, y2, conf, class_id = detection[:6]
        
        # Calculate center and dimensions
        cx = (x1 + x2) / 2
        cy = (y1 + y2) / 2
        w = x2 - x1
        h = y2 - y1
        
        class_name = class_names.get(int(class_id), f'class_{int(class_id)}')
        
        return cls(
            id=item_id,
            class_name=class_name,
            x=cx,
            y=cy,
            width=w,
            height=h,
            confidence=float(conf),
            original_bbox=(float(x1), float(y1), float(x2), float(y2))
        )
    
    def __repr__(self):
        return f"FurnitureItem(id={self.id}, class='{self.class_name}', pos=({self.x:.1f}, {self.y:.1f}), angle={self.angle:.1f}°)"
