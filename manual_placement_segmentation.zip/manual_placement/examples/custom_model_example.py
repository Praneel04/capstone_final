"""
Example: Using Roboflow API with the Floor Plan Correction App

This script demonstrates how to integrate with Roboflow for furniture detection.
"""

import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from detection import RoboflowDetector, FurnitureItem
from detection.roboflow_detector import MockRoboflowDetector
import cv2


def example_1_use_roboflow_api():
    """Use Roboflow hosted API for detection."""
    
    # Create detector with your credentials
    detector = RoboflowDetector(
        api_key="bngHGPb2UJDgzZlQGaTu",  # Replace with your API key
        model_id="furniture-ya4pe/1",      # Replace with your model
        confidence_threshold=0.25
    )
    
    return detector


def example_2_custom_roboflow_model():
    """Use a different Roboflow model."""
    
    detector = RoboflowDetector(
        api_key="your_api_key_here",
        model_id="your-custom-project/1",
        api_url="https://serverless.roboflow.com",  # or your deployment URL
        confidence_threshold=0.3
    )
    
    return detector


def example_3_detect_and_process():
    """Complete example of detection and processing."""
    
    # Use mock detector for testing (no API needed)
    detector = MockRoboflowDetector()
    
    # Load an image
    image_path = "path/to/floor_plan.png"
    
    # For testing, create a dummy image if file doesn't exist
    try:
        image = cv2.imread(image_path)
        if image is None:
            print(f"Creating test image since {image_path} not found")
            image = (np.ones((600, 800, 3)) * 200).astype(np.uint8)
    except:
        import numpy as np
        image = (np.ones((600, 800, 3)) * 200).astype(np.uint8)
    
    # Run detection
    furniture_items = detector.detect(image, extract_crops=True)
    
    print(f"Detected {len(furniture_items)} furniture items:")
    for item in furniture_items:
        print(f"  - {item.class_name}: pos=({item.x:.1f}, {item.y:.1f}), "
              f"size=({item.width:.1f}x{item.height:.1f}), "
              f"conf={item.confidence:.2%}")
    
    # Modify positions programmatically
    for item in furniture_items:
        # Example: shift all items by 50 pixels
        item.move_by(50, 50)
        
        # Example: rotate beds by 90 degrees
        if item.class_name == 'bed':
            item.rotate_to(90)
    
    # Export to JSON
    import json
    layout = {
        'image_path': image_path,
        'items': [item.to_dict() for item in furniture_items]
    }
    
    with open('layout.json', 'w') as f:
        json.dump(layout, f, indent=2)
    
    print("Layout saved to layout.json")


def example_4_with_real_api():
    """Example using real Roboflow API."""
    
    # Initialize detector
    detector = RoboflowDetector(
        api_key="bngHGPb2UJDgzZlQGaTu",
        model_id="furniture-ya4pe/1"
    )
    
    # Load your floor plan
    image_path = "floor_plan.png"  # Replace with your image
    
    try:
        # Detect furniture
        items = detector.detect(image_path, extract_crops=True)
        
        print(f"\nDetected {len(items)} furniture items:")
        for item in items:
            print(f"  {item.class_name}: "
                  f"center=({item.x:.0f}, {item.y:.0f}), "
                  f"size={item.width:.0f}x{item.height:.0f}, "
                  f"confidence={item.confidence:.1%}")
            
            # Check if segmentation mask was extracted
            if hasattr(item, 'polygon') and item.polygon is not None:
                print(f"    (has segmentation mask with {len(item.polygon)} points)")
        
        return items
        
    except FileNotFoundError:
        print(f"Image not found: {image_path}")
    except Exception as e:
        print(f"Error: {e}")


def example_5_run_gui():
    """Run the GUI application."""
    
    from PyQt5.QtWidgets import QApplication
    from ui.main_window import MainWindow
    
    # Create application
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    
    # Create and show main window
    window = MainWindow()
    window.show()
    
    return app.exec_()


if __name__ == "__main__":
    import numpy as np
    
    print("=== Roboflow Detection Examples ===\n")
    
    # Run mock detection example (no API needed)
    print("Running mock detection example...")
    example_3_detect_and_process()
    
    print("\n" + "="*50)
    print("To run with real API, uncomment example_4_with_real_api()")
    print("To run the GUI, uncomment example_5_run_gui()")
    
    # Uncomment to run with real API:
    # example_4_with_real_api()
    
    # Uncomment to run GUI:
    # example_5_run_gui()
