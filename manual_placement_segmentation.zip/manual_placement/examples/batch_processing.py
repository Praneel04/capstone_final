"""
Example: Batch Processing Floor Plans

This script demonstrates how to process multiple floor plans
programmatically without the GUI.
"""

import sys
import json
from pathlib import Path
import cv2

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from detection import YOLODetector, FurnitureItem
from detection.yolo_detector import MockYOLODetector
from utils import apply_furniture_to_floorplan, load_furniture_catalog


def process_floor_plans(
    input_dir: str,
    output_dir: str,
    model_path: str = None,
    catalog_path: str = None,
    confidence: float = 0.25
):
    """
    Process multiple floor plan images.
    
    Args:
        input_dir: Directory containing floor plan images
        output_dir: Directory to save results
        model_path: Path to YOLO model (uses mock if None)
        catalog_path: Path to furniture icon catalog
        confidence: Detection confidence threshold
    """
    
    input_path = Path(input_dir)
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    # Load detector
    if model_path:
        detector = YOLODetector(
            model_path=model_path,
            confidence_threshold=confidence
        )
        print(f"Using model: {model_path}")
    else:
        detector = MockYOLODetector()
        print("Using mock detector (for testing)")
    
    # Load furniture catalog if provided
    catalog = {}
    if catalog_path:
        catalog = load_furniture_catalog(catalog_path)
        print(f"Loaded {len(catalog)} furniture icons")
    
    # Process each image
    image_extensions = {'.png', '.jpg', '.jpeg', '.bmp', '.tiff'}
    images = [f for f in input_path.iterdir() 
              if f.suffix.lower() in image_extensions]
    
    print(f"Found {len(images)} images to process")
    
    results = []
    
    for i, image_file in enumerate(images, 1):
        print(f"Processing [{i}/{len(images)}]: {image_file.name}")
        
        try:
            # Load image
            image = cv2.imread(str(image_file))
            if image is None:
                print(f"  Error: Could not load image")
                continue
            
            # Detect furniture
            items = detector.detect(image, extract_crops=True)
            print(f"  Detected {len(items)} furniture items")
            
            # Apply furniture icons from catalog
            result_image = apply_furniture_to_floorplan(image, items, catalog)
            
            # Save result image
            output_image_path = output_path / f"corrected_{image_file.name}"
            cv2.imwrite(str(output_image_path), result_image)
            
            # Save layout JSON
            layout = {
                'source_image': str(image_file),
                'items': [item.to_dict() for item in items]
            }
            
            output_json_path = output_path / f"{image_file.stem}_layout.json"
            with open(output_json_path, 'w') as f:
                json.dump(layout, f, indent=2)
            
            results.append({
                'image': image_file.name,
                'items_count': len(items),
                'output_image': str(output_image_path),
                'output_json': str(output_json_path)
            })
            
        except Exception as e:
            print(f"  Error: {e}")
            continue
    
    # Save summary
    summary = {
        'total_images': len(images),
        'processed': len(results),
        'failed': len(images) - len(results),
        'results': results
    }
    
    summary_path = output_path / 'processing_summary.json'
    with open(summary_path, 'w') as f:
        json.dump(summary, f, indent=2)
    
    print(f"\nProcessing complete!")
    print(f"  Processed: {len(results)}/{len(images)}")
    print(f"  Results saved to: {output_path}")
    
    return summary


def apply_manual_corrections(
    image_path: str,
    corrections_json: str,
    output_path: str,
    catalog_path: str = None
):
    """
    Apply manual corrections from JSON to a floor plan.
    
    Args:
        image_path: Path to original floor plan
        corrections_json: Path to JSON file with corrected positions
        output_path: Path to save result
        catalog_path: Path to furniture icon catalog
    """
    
    # Load image
    image = cv2.imread(image_path)
    if image is None:
        raise ValueError(f"Could not load image: {image_path}")
    
    # Load corrections
    with open(corrections_json, 'r') as f:
        layout = json.load(f)
    
    # Convert to FurnitureItem objects
    items = [FurnitureItem.from_dict(item_data) 
             for item_data in layout.get('items', [])]
    
    print(f"Loaded {len(items)} furniture items from corrections")
    
    # Load catalog
    catalog = {}
    if catalog_path:
        catalog = load_furniture_catalog(catalog_path)
    
    # Apply to image
    result = apply_furniture_to_floorplan(image, items, catalog)
    
    # Save result
    cv2.imwrite(output_path, result)
    print(f"Saved corrected floor plan to: {output_path}")


if __name__ == "__main__":
    # Example usage
    
    # Batch process a directory
    # process_floor_plans(
    #     input_dir="floor_plans/",
    #     output_dir="output/",
    #     model_path="models/yolo_furniture.pt",
    #     catalog_path="catalog/",
    #     confidence=0.3
    # )
    
    # Apply manual corrections
    # apply_manual_corrections(
    #     image_path="floor_plan.png",
    #     corrections_json="corrections.json",
    #     output_path="corrected.png",
    #     catalog_path="catalog/"
    # )
    
    print("Batch processing example.")
    print("Uncomment the example calls above to run.")
