"""
Furniture Widget
Displays a draggable furniture item for the sidebar catalog.
"""

from PyQt5.QtWidgets import QFrame, QLabel, QVBoxLayout
from PyQt5.QtCore import Qt, QMimeData, pyqtSignal
from PyQt5.QtGui import QDrag, QPixmap, QPainter, QColor


class FurnitureWidget(QFrame):
    """Widget representing a furniture item in the catalog sidebar."""
    
    clicked = pyqtSignal(str)  # Emits class name when clicked
    
    def __init__(self, class_name: str, icon_pixmap: QPixmap = None, parent=None):
        super().__init__(parent)
        
        self.class_name = class_name
        self.icon_pixmap = icon_pixmap
        
        self.setFrameStyle(QFrame.Box | QFrame.Raised)
        self.setLineWidth(1)
        self.setFixedSize(80, 80)
        self.setCursor(Qt.OpenHandCursor)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)
        layout.setSpacing(2)
        
        # Icon label
        self.icon_label = QLabel()
        self.icon_label.setAlignment(Qt.AlignCenter)
        
        if icon_pixmap:
            scaled = icon_pixmap.scaled(50, 50, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.icon_label.setPixmap(scaled)
        else:
            # Create placeholder
            self.icon_label.setStyleSheet("""
                background-color: #555;
                border-radius: 5px;
            """)
            self.icon_label.setFixedSize(50, 50)
        
        layout.addWidget(self.icon_label, alignment=Qt.AlignCenter)
        
        # Name label
        self.name_label = QLabel(class_name)
        self.name_label.setAlignment(Qt.AlignCenter)
        self.name_label.setStyleSheet("font-size: 10px;")
        layout.addWidget(self.name_label)
        
        self.setStyleSheet("""
            FurnitureWidget {
                background-color: #3c3c3c;
                border: 1px solid #555;
                border-radius: 5px;
            }
            FurnitureWidget:hover {
                background-color: #4a4a4a;
                border: 1px solid #888;
            }
        """)
    
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.clicked.emit(self.class_name)
    
    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.LeftButton:
            drag = QDrag(self)
            mime = QMimeData()
            mime.setText(self.class_name)
            drag.setMimeData(mime)
            
            # Create drag pixmap
            if self.icon_pixmap:
                drag.setPixmap(self.icon_pixmap.scaled(40, 40, Qt.KeepAspectRatio))
            else:
                pixmap = QPixmap(40, 40)
                pixmap.fill(QColor(100, 100, 100))
                painter = QPainter(pixmap)
                painter.setPen(QColor(255, 255, 255))
                painter.drawText(pixmap.rect(), Qt.AlignCenter, self.class_name[:3])
                painter.end()
                drag.setPixmap(pixmap)
            
            drag.exec_(Qt.CopyAction | Qt.MoveAction)
