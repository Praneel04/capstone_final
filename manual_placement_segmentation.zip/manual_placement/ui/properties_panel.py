"""
Properties Panel
Displays and allows editing of selected furniture item properties.
"""

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
    QDoubleSpinBox, QSpinBox, QLineEdit, QPushButton,
    QGroupBox, QFormLayout, QSlider, QFrame
)
from PyQt5.QtCore import Qt, pyqtSignal

from detection.furniture_item import FurnitureItem


class PropertiesPanel(QWidget):
    """Panel for viewing and editing furniture properties."""
    
    # Signals
    property_changed = pyqtSignal(object)  # Emits updated FurnitureItem
    delete_requested = pyqtSignal(object)  # Emits FurnitureItem to delete
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.current_item: FurnitureItem = None
        self._updating = False  # Prevent feedback loops
        
        self.setup_ui()
    
    def setup_ui(self):
        """Setup the UI components."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        
        # Title
        title = QLabel("Properties")
        title.setStyleSheet("font-size: 14px; font-weight: bold;")
        layout.addWidget(title)
        
        # No selection message
        self.no_selection_label = QLabel("No furniture selected")
        self.no_selection_label.setStyleSheet("color: #888; font-style: italic;")
        self.no_selection_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.no_selection_label)
        
        # Properties group
        self.properties_group = QGroupBox("Selected Item")
        properties_layout = QFormLayout()
        
        # Class name (read-only)
        self.class_label = QLabel()
        properties_layout.addRow("Type:", self.class_label)
        
        # ID (read-only)
        self.id_label = QLabel()
        properties_layout.addRow("ID:", self.id_label)
        
        # Confidence (read-only)
        self.conf_label = QLabel()
        properties_layout.addRow("Confidence:", self.conf_label)
        
        self.properties_group.setLayout(properties_layout)
        layout.addWidget(self.properties_group)
        
        # Position group
        self.position_group = QGroupBox("Position")
        pos_layout = QFormLayout()
        
        # X position
        self.x_spin = QDoubleSpinBox()
        self.x_spin.setRange(-10000, 10000)
        self.x_spin.setDecimals(1)
        self.x_spin.valueChanged.connect(self._on_position_changed)
        pos_layout.addRow("X:", self.x_spin)
        
        # Y position
        self.y_spin = QDoubleSpinBox()
        self.y_spin.setRange(-10000, 10000)
        self.y_spin.setDecimals(1)
        self.y_spin.valueChanged.connect(self._on_position_changed)
        pos_layout.addRow("Y:", self.y_spin)
        
        self.position_group.setLayout(pos_layout)
        layout.addWidget(self.position_group)
        
        # Size group
        self.size_group = QGroupBox("Size")
        size_layout = QFormLayout()
        
        # Width
        self.width_spin = QDoubleSpinBox()
        self.width_spin.setRange(1, 10000)
        self.width_spin.setDecimals(1)
        self.width_spin.valueChanged.connect(self._on_size_changed)
        size_layout.addRow("Width:", self.width_spin)
        
        # Height
        self.height_spin = QDoubleSpinBox()
        self.height_spin.setRange(1, 10000)
        self.height_spin.setDecimals(1)
        self.height_spin.valueChanged.connect(self._on_size_changed)
        size_layout.addRow("Height:", self.height_spin)
        
        self.size_group.setLayout(size_layout)
        layout.addWidget(self.size_group)
        
        # Rotation group
        self.rotation_group = QGroupBox("Rotation")
        rot_layout = QVBoxLayout()
        
        # Angle slider
        slider_layout = QHBoxLayout()
        self.angle_slider = QSlider(Qt.Horizontal)
        self.angle_slider.setRange(0, 360)
        self.angle_slider.valueChanged.connect(self._on_angle_slider_changed)
        slider_layout.addWidget(self.angle_slider)
        
        self.angle_spin = QSpinBox()
        self.angle_spin.setRange(0, 360)
        self.angle_spin.setSuffix("°")
        self.angle_spin.valueChanged.connect(self._on_angle_spin_changed)
        slider_layout.addWidget(self.angle_spin)
        
        rot_layout.addLayout(slider_layout)
        
        # Quick rotation buttons
        quick_rot_layout = QHBoxLayout()
        
        for angle in [0, 90, 180, 270]:
            btn = QPushButton(f"{angle}°")
            btn.setFixedWidth(50)
            btn.clicked.connect(lambda checked, a=angle: self._set_angle(a))
            quick_rot_layout.addWidget(btn)
        
        rot_layout.addLayout(quick_rot_layout)
        
        self.rotation_group.setLayout(rot_layout)
        layout.addWidget(self.rotation_group)
        
        # Actions
        actions_layout = QHBoxLayout()
        
        self.reset_btn = QPushButton("Reset Position")
        self.reset_btn.clicked.connect(self._on_reset)
        actions_layout.addWidget(self.reset_btn)
        
        self.delete_btn = QPushButton("Delete")
        self.delete_btn.setStyleSheet("background-color: #8B0000;")
        self.delete_btn.clicked.connect(self._on_delete)
        actions_layout.addWidget(self.delete_btn)
        
        layout.addLayout(actions_layout)
        
        # Spacer
        layout.addStretch()
        
        # Initially hide properties
        self._set_properties_visible(False)
    
    def _set_properties_visible(self, visible: bool):
        """Show/hide property editors."""
        self.no_selection_label.setVisible(not visible)
        self.properties_group.setVisible(visible)
        self.position_group.setVisible(visible)
        self.size_group.setVisible(visible)
        self.rotation_group.setVisible(visible)
        self.reset_btn.setVisible(visible)
        self.delete_btn.setVisible(visible)
    
    def set_item(self, item: FurnitureItem):
        """Set the current furniture item to display."""
        self.current_item = item
        
        if item is None:
            self._set_properties_visible(False)
            return
        
        self._set_properties_visible(True)
        self._update_display()
    
    def _update_display(self):
        """Update all property displays."""
        if self.current_item is None:
            return
        
        self._updating = True
        
        item = self.current_item
        
        # Properties
        self.class_label.setText(item.class_name)
        self.id_label.setText(str(item.id))
        self.conf_label.setText(f"{item.confidence:.2%}")
        
        # Position
        self.x_spin.setValue(item.x)
        self.y_spin.setValue(item.y)
        
        # Size
        self.width_spin.setValue(item.width)
        self.height_spin.setValue(item.height)
        
        # Rotation
        self.angle_slider.setValue(int(item.angle))
        self.angle_spin.setValue(int(item.angle))
        
        self._updating = False
    
    def _on_position_changed(self):
        """Handle position change."""
        if self._updating or self.current_item is None:
            return
        
        self.current_item.x = self.x_spin.value()
        self.current_item.y = self.y_spin.value()
        self.property_changed.emit(self.current_item)
    
    def _on_size_changed(self):
        """Handle size change."""
        if self._updating or self.current_item is None:
            return
        
        self.current_item.width = self.width_spin.value()
        self.current_item.height = self.height_spin.value()
        self.property_changed.emit(self.current_item)
    
    def _on_angle_slider_changed(self, value):
        """Handle angle slider change."""
        if self._updating or self.current_item is None:
            return
        
        self._updating = True
        self.angle_spin.setValue(value)
        self._updating = False
        
        self.current_item.angle = value
        self.property_changed.emit(self.current_item)
    
    def _on_angle_spin_changed(self, value):
        """Handle angle spin change."""
        if self._updating or self.current_item is None:
            return
        
        self._updating = True
        self.angle_slider.setValue(value)
        self._updating = False
        
        self.current_item.angle = value
        self.property_changed.emit(self.current_item)
    
    def _set_angle(self, angle: int):
        """Set angle to a specific value."""
        if self.current_item is None:
            return
        
        self._updating = True
        self.angle_slider.setValue(angle)
        self.angle_spin.setValue(angle)
        self._updating = False
        
        self.current_item.angle = angle
        self.property_changed.emit(self.current_item)
    
    def _on_reset(self):
        """Reset item to original position."""
        if self.current_item is None:
            return
        
        if self.current_item.original_bbox:
            x1, y1, x2, y2 = self.current_item.original_bbox
            self.current_item.x = (x1 + x2) / 2
            self.current_item.y = (y1 + y2) / 2
            self.current_item.width = x2 - x1
            self.current_item.height = y2 - y1
        
        self.current_item.angle = 0
        
        self._update_display()
        self.property_changed.emit(self.current_item)
    
    def _on_delete(self):
        """Request deletion of current item."""
        if self.current_item is not None:
            self.delete_requested.emit(self.current_item)
    
    def update_from_item(self):
        """Update display from current item (after external changes)."""
        self._update_display()
