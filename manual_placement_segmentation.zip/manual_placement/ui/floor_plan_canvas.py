"""
Floor Plan Canvas Widget
Interactive canvas for displaying and manipulating furniture on the floor plan.
"""

import math
from typing import List, Optional, Tuple
import numpy as np
import cv2
from PIL import Image

from PyQt5.QtWidgets import QWidget, QMenu, QAction
from PyQt5.QtCore import Qt, QPoint, QPointF, QRectF, pyqtSignal
from PyQt5.QtGui import (
    QPainter, QPen, QBrush, QColor, QImage, QPixmap, 
    QTransform, QPainterPath, QCursor, QFont
)

from detection.furniture_item import FurnitureItem


class FloorPlanCanvas(QWidget):
    """
    Interactive canvas for floor plan visualization and furniture manipulation.
    
    Features:
    - Display floor plan image
    - Show detected furniture with bounding boxes
    - Drag and drop furniture
    - Rotate furniture with mouse wheel or handles
    - Real-time preview of changes
    """
    
    # Signals
    furniture_selected = pyqtSignal(object)  # Emits FurnitureItem or None
    furniture_moved = pyqtSignal(object)     # Emits FurnitureItem
    furniture_rotated = pyqtSignal(object)   # Emits FurnitureItem
    furniture_deleted = pyqtSignal(object)   # Emits FurnitureItem
    canvas_updated = pyqtSignal()            # Emits when canvas needs refresh
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # Floor plan image
        self.floor_plan: Optional[np.ndarray] = None  # Original floor plan
        self.floor_plan_masked: Optional[np.ndarray] = None  # Floor plan with furniture masked out
        self.floor_plan_pixmap: Optional[QPixmap] = None
        self.original_size: Tuple[int, int] = (800, 600)
        
        # Furniture items
        self.furniture_items: List[FurnitureItem] = []
        self.selected_item: Optional[FurnitureItem] = None
        
        # Interaction state
        self.dragging = False
        self.rotating = False
        self.drag_start: Optional[QPointF] = None
        self.item_start_pos: Optional[Tuple[float, float]] = None
        self.rotation_start_angle: float = 0
        
        # View settings
        self.zoom_level = 1.0
        self.pan_offset = QPointF(0, 0)
        self.show_labels = True
        self.show_bboxes = True
        self.show_icons = True
        
        # Visual settings
        self.selection_color = QColor(255, 255, 0)
        self.hover_color = QColor(255, 200, 0, 150)
        self.bbox_line_width = 2
        self.handle_size = 10
        
        # Furniture icons catalog
        self.icon_catalog: dict = {}
        
        # Setup widget
        self.setMinimumSize(400, 300)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self._show_context_menu)
        
        # Hover item for highlighting
        self.hover_item: Optional[FurnitureItem] = None
    
    def set_floor_plan(self, image: np.ndarray):
        """Set the floor plan image."""
        self.floor_plan = image.copy()
        self.floor_plan_masked = image.copy()  # Will be updated when furniture is detected
        self.original_size = (image.shape[1], image.shape[0])
        self._update_pixmap()
        self.update()
    
    def set_furniture_items(self, items: List[FurnitureItem]):
        """Set the list of furniture items and mask them from the floor plan."""
        self.furniture_items = items
        self.selected_item = None
        self.furniture_selected.emit(None)
        
        # Extract furniture images and mask them from the floor plan
        if self.floor_plan is not None and items:
            self._extract_and_mask_furniture(items)
        
        self.update()
    
    def _extract_and_mask_furniture(self, items: List[FurnitureItem]):
        """Extract furniture images and create a masked floor plan using polygons."""
        if self.floor_plan is None:
            return
        
        # Start with the original floor plan
        self.floor_plan_masked = self.floor_plan.copy()
        
        for item in items:
            # Use polygon if available for precise masking
            if item.polygon is not None:
                # Extract using polygon mask (already done in detector with transparency)
                # Just need to mask out the original location
                self._inpaint_polygon(self.floor_plan_masked, item.polygon)
            else:
                # Fallback to bounding box
                x1, y1, x2, y2 = item.original_bbox
                x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
                
                # Clamp to image bounds
                h, w = self.floor_plan.shape[:2]
                x1 = max(0, x1)
                y1 = max(0, y1)
                x2 = min(w, x2)
                y2 = min(h, y2)
                
                if x2 <= x1 or y2 <= y1:
                    continue
                
                # Extract the furniture image if not already done
                if item.image is None:
                    item.image = self.floor_plan[y1:y2, x1:x2].copy()
                
                # Mask out using bounding box
                self._inpaint_region(self.floor_plan_masked, x1, y1, x2, y2)
        
        # Update the pixmap
        self._update_pixmap()
    
    def _inpaint_polygon(self, image: np.ndarray, polygon: np.ndarray):
        """Inpaint a polygon region using OpenCV inpainting."""
        # Create mask from polygon
        mask = np.zeros(image.shape[:2], dtype=np.uint8)
        cv2.fillPoly(mask, [polygon], 255)
        
        # Dilate the mask to expand coverage and avoid residue
        # This ensures we cover any edge pixels that might be missed
        kernel = np.ones((7, 7), np.uint8)
        mask = cv2.dilate(mask, kernel, iterations=2)
        
        # Use OpenCV inpainting for better results
        # INPAINT_TELEA is faster, INPAINT_NS gives better quality
        # Use larger radius for better coverage
        try:
            inpainted = cv2.inpaint(image, mask, inpaintRadius=7, flags=cv2.INPAINT_TELEA)
            # Copy inpainted region back
            image[mask > 0] = inpainted[mask > 0]
        except Exception:
            # Fallback: fill with surrounding color
            self._fill_polygon_with_surrounding(image, polygon, mask)
    
    def _fill_polygon_with_surrounding(self, image: np.ndarray, polygon: np.ndarray, mask: np.ndarray):
        """Fill polygon with surrounding colors (fallback method)."""
        # Dilate mask further to get border region outside the already dilated mask
        kernel = np.ones((7, 7), np.uint8)
        dilated = cv2.dilate(mask, kernel, iterations=3)
        border_mask = dilated - mask
        
        # Get border pixels
        border_pixels = image[border_mask > 0]
        
        if len(border_pixels) > 0:
            fill_color = np.median(border_pixels, axis=0).astype(np.uint8)
        else:
            fill_color = np.array([200, 200, 200], dtype=np.uint8)
        
        # Fill the polygon region
        image[mask > 0] = fill_color
    
    def _inpaint_region(self, image: np.ndarray, x1: int, y1: int, x2: int, y2: int):
        """Fill a region with inpainted content (simple approach using surrounding colors)."""
        h, w = image.shape[:2]
        
        # Sample colors from the border of the region
        border_pixels = []
        
        # Top border
        if y1 > 0:
            border_pixels.extend(image[y1-1, x1:x2].tolist())
        # Bottom border
        if y2 < h:
            border_pixels.extend(image[y2, x1:x2].tolist())
        # Left border
        if x1 > 0:
            border_pixels.extend(image[y1:y2, x1-1].tolist())
        # Right border
        if x2 < w:
            border_pixels.extend(image[y1:y2, x2].tolist())
        
        if border_pixels:
            # Use median color for a cleaner fill
            fill_color = np.median(border_pixels, axis=0).astype(np.uint8)
        else:
            # Default to light gray (floor color)
            fill_color = np.array([200, 200, 200], dtype=np.uint8)
        
        # Fill the region
        image[y1:y2, x1:x2] = fill_color
    
    def add_furniture_item(self, item: FurnitureItem):
        """Add a furniture item to the canvas."""
        self.furniture_items.append(item)
        self.update()
    
    def remove_furniture_item(self, item: FurnitureItem):
        """Remove a furniture item from the canvas."""
        if item in self.furniture_items:
            self.furniture_items.remove(item)
            if self.selected_item == item:
                self.selected_item = None
                self.furniture_selected.emit(None)
            self.furniture_deleted.emit(item)
            self.update()
    
    def clear_furniture(self):
        """Remove all furniture items."""
        self.furniture_items.clear()
        self.selected_item = None
        self.furniture_selected.emit(None)
        self.update()
    
    def set_icon_catalog(self, catalog: dict):
        """Set the furniture icon catalog."""
        self.icon_catalog = catalog
    
    def load_icon_catalog(self, catalog_path: str):
        """Load furniture icons from a directory."""
        from pathlib import Path
        catalog_dir = Path(catalog_path)
        
        if catalog_dir.exists():
            for icon_file in catalog_dir.glob('*.png'):
                class_name = icon_file.stem
                icon_img = cv2.imread(str(icon_file), cv2.IMREAD_UNCHANGED)
                if icon_img is not None:
                    self.icon_catalog[class_name] = icon_img
    
    def _update_pixmap(self):
        """Convert floor plan to QPixmap for display."""
        # Use masked floor plan if available, otherwise original
        image = self.floor_plan_masked if self.floor_plan_masked is not None else self.floor_plan
        
        if image is None:
            return
        
        # Convert BGR to RGB
        if len(image.shape) == 3:
            rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        else:
            rgb = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
        
        h, w, ch = rgb.shape
        bytes_per_line = ch * w
        
        qimg = QImage(rgb.data, w, h, bytes_per_line, QImage.Format_RGB888)
        self.floor_plan_pixmap = QPixmap.fromImage(qimg.copy())
    
    def _image_to_widget(self, x: float, y: float) -> QPointF:
        """Convert image coordinates to widget coordinates."""
        return QPointF(
            x * self.zoom_level + self.pan_offset.x(),
            y * self.zoom_level + self.pan_offset.y()
        )
    
    def _widget_to_image(self, pos: QPointF) -> QPointF:
        """Convert widget coordinates to image coordinates."""
        return QPointF(
            (pos.x() - self.pan_offset.x()) / self.zoom_level,
            (pos.y() - self.pan_offset.y()) / self.zoom_level
        )
    
    def _get_item_at(self, pos: QPointF) -> Optional[FurnitureItem]:
        """Get the furniture item at the given widget position."""
        img_pos = self._widget_to_image(pos)
        
        # Check in reverse order (top items first)
        for item in reversed(self.furniture_items):
            if item.contains_point(img_pos.x(), img_pos.y()):
                return item
        
        return None
    
    def _is_on_rotation_handle(self, pos: QPointF, item: FurnitureItem) -> bool:
        """Check if position is on the rotation handle of an item."""
        if item is None:
            return False
        
        # Handle is above the item center
        handle_offset = max(item.width, item.height) / 2 + 20
        handle_pos = self._image_to_widget(item.x, item.y - handle_offset)
        
        dx = pos.x() - handle_pos.x()
        dy = pos.y() - handle_pos.y()
        distance = math.sqrt(dx * dx + dy * dy)
        
        return distance <= self.handle_size
    
    def paintEvent(self, event):
        """Paint the canvas."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setRenderHint(QPainter.SmoothPixmapTransform)
        
        # Fill background
        painter.fillRect(self.rect(), QColor(50, 50, 50))
        
        # Draw floor plan
        if self.floor_plan_pixmap:
            painter.save()
            painter.translate(self.pan_offset)
            painter.scale(self.zoom_level, self.zoom_level)
            painter.drawPixmap(0, 0, self.floor_plan_pixmap)
            painter.restore()
        
        # Draw furniture items
        for item in self.furniture_items:
            self._draw_furniture_item(painter, item)
        
        # Draw selection handles for selected item
        if self.selected_item:
            self._draw_selection_handles(painter, self.selected_item)
        
        painter.end()
    
    def _draw_furniture_item(self, painter: QPainter, item: FurnitureItem):
        """Draw a single furniture item."""
        # Get widget coordinates
        center = self._image_to_widget(item.x, item.y)
        w = item.width * self.zoom_level
        h = item.height * self.zoom_level
        
        painter.save()
        
        # Apply rotation
        painter.translate(center)
        painter.rotate(item.angle)
        
        # Always draw furniture image (extracted from floor plan or icon)
        img = item.icon if item.icon is not None else item.image
        if img is not None:
            self._draw_furniture_image(painter, img, w, h)
        
        # Draw outline (polygon or bounding box)
        if self.show_bboxes:
            is_selected = item == self.selected_item
            is_hovered = item == self.hover_item
            
            if is_selected:
                pen = QPen(self.selection_color, self.bbox_line_width + 1)
            elif is_hovered:
                pen = QPen(self.hover_color, self.bbox_line_width)
            else:
                color = QColor(*item.color)
                pen = QPen(color, self.bbox_line_width)
            
            painter.setPen(pen)
            painter.setBrush(Qt.NoBrush)
            
            # Use polygon if available, otherwise bounding box
            if item.polygon is not None:
                self._draw_polygon_outline(painter, item, w, h)
            else:
                painter.drawRect(QRectF(-w/2, -h/2, w, h))
        
        painter.restore()
        
        # Draw label (without rotation)
        if self.show_labels:
            self._draw_label(painter, item, center)
    
    def _draw_polygon_outline(self, painter: QPainter, item: FurnitureItem, w: float, h: float):
        """Draw the polygon outline for a furniture item."""
        if item.polygon is None:
            return
        
        # Get polygon bounds from original bbox
        x1, y1, x2, y2 = item.original_bbox
        orig_w = x2 - x1
        orig_h = y2 - y1
        
        if orig_w <= 0 or orig_h <= 0:
            return
        
        # Scale polygon to fit current size
        scale_x = w / orig_w
        scale_y = h / orig_h
        
        # Translate and scale polygon points to widget coordinates
        path = QPainterPath()
        first = True
        
        for point in item.polygon:
            # Get point relative to original bbox center
            px = (point[0] - (x1 + orig_w/2)) * scale_x
            py = (point[1] - (y1 + orig_h/2)) * scale_y
            
            if first:
                path.moveTo(px, py)
                first = False
            else:
                path.lineTo(px, py)
        
        path.closeSubpath()
        painter.drawPath(path)
    
    def _draw_furniture_image(self, painter: QPainter, img: np.ndarray, w: float, h: float):
        """Draw a furniture image centered at origin."""
        if img is None:
            return
        
        # Convert to QPixmap
        if len(img.shape) == 3:
            if img.shape[2] == 4:
                # BGRA
                rgb = cv2.cvtColor(img, cv2.COLOR_BGRA2RGBA)
                qformat = QImage.Format_RGBA8888
            else:
                # BGR
                rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                qformat = QImage.Format_RGB888
        else:
            rgb = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
            qformat = QImage.Format_RGB888
        
        ih, iw = rgb.shape[:2]
        ch = rgb.shape[2] if len(rgb.shape) == 3 else 1
        bytes_per_line = ch * iw
        
        qimg = QImage(rgb.data, iw, ih, bytes_per_line, qformat)
        pixmap = QPixmap.fromImage(qimg)
        
        # Scale and draw
        scaled = pixmap.scaled(int(w), int(h), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        painter.drawPixmap(int(-scaled.width()/2), int(-scaled.height()/2), scaled)
    
    def _draw_label(self, painter: QPainter, item: FurnitureItem, center: QPointF):
        """Draw the furniture label."""
        font = QFont('Arial', 9)
        painter.setFont(font)
        
        # Label background
        label = f"{item.class_name}"
        metrics = painter.fontMetrics()
        text_rect = metrics.boundingRect(label)
        
        bg_rect = QRectF(
            center.x() - text_rect.width()/2 - 3,
            center.y() + item.height * self.zoom_level / 2 + 2,
            text_rect.width() + 6,
            text_rect.height() + 2
        )
        
        painter.fillRect(bg_rect, QColor(0, 0, 0, 180))
        painter.setPen(QColor(255, 255, 255))
        painter.drawText(bg_rect, Qt.AlignCenter, label)
    
    def _draw_selection_handles(self, painter: QPainter, item: FurnitureItem):
        """Draw selection handles for the selected item."""
        center = self._image_to_widget(item.x, item.y)
        w = item.width * self.zoom_level
        h = item.height * self.zoom_level
        
        painter.save()
        painter.translate(center)
        painter.rotate(item.angle)
        
        # Corner handles
        handle_size = self.handle_size
        corners = [
            (-w/2, -h/2), (w/2, -h/2),
            (-w/2, h/2), (w/2, h/2)
        ]
        
        painter.setPen(QPen(Qt.white, 1))
        painter.setBrush(QBrush(self.selection_color))
        
        for cx, cy in corners:
            painter.drawRect(QRectF(
                cx - handle_size/2, cy - handle_size/2,
                handle_size, handle_size
            ))
        
        painter.restore()
        
        # Rotation handle (above the item)
        handle_offset = max(w, h) / 2 + 20
        painter.save()
        painter.translate(center)
        
        # Line to rotation handle
        painter.setPen(QPen(self.selection_color, 1, Qt.DashLine))
        painter.drawLine(QPointF(0, -h/2), QPointF(0, -handle_offset))
        
        # Rotation handle circle
        painter.setBrush(QBrush(QColor(0, 200, 255)))
        painter.setPen(QPen(Qt.white, 1))
        painter.drawEllipse(QPointF(0, -handle_offset), handle_size/2, handle_size/2)
        
        painter.restore()
    
    def mousePressEvent(self, event):
        """Handle mouse press events."""
        if event.button() == Qt.LeftButton:
            pos = QPointF(event.pos())
            
            # Check for rotation handle first
            if self.selected_item and self._is_on_rotation_handle(pos, self.selected_item):
                self.rotating = True
                self.rotation_start_angle = self.selected_item.angle
                # Calculate initial angle from center to mouse
                center = self._image_to_widget(self.selected_item.x, self.selected_item.y)
                dx = pos.x() - center.x()
                dy = pos.y() - center.y()
                self.drag_start = QPointF(math.atan2(dy, dx), 0)
                self.setCursor(Qt.ClosedHandCursor)
                return
            
            # Check for item selection
            item = self._get_item_at(pos)
            
            if item:
                # Select and start dragging
                self.selected_item = item
                self.dragging = True
                self.drag_start = pos
                self.item_start_pos = (item.x, item.y)
                self.furniture_selected.emit(item)
                self.setCursor(Qt.ClosedHandCursor)
            else:
                # Deselect
                self.selected_item = None
                self.furniture_selected.emit(None)
            
            self.update()
        
        elif event.button() == Qt.MiddleButton:
            # Pan view
            self.drag_start = QPointF(event.pos())
            self.setCursor(Qt.ClosedHandCursor)
    
    def mouseMoveEvent(self, event):
        """Handle mouse move events."""
        pos = QPointF(event.pos())
        
        if self.dragging and self.selected_item:
            # Move furniture
            img_pos = self._widget_to_image(pos)
            img_start = self._widget_to_image(self.drag_start)
            
            dx = img_pos.x() - img_start.x()
            dy = img_pos.y() - img_start.y()
            
            self.selected_item.x = self.item_start_pos[0] + dx
            self.selected_item.y = self.item_start_pos[1] + dy
            
            self.furniture_moved.emit(self.selected_item)
            self.update()
        
        elif self.rotating and self.selected_item:
            # Rotate furniture
            center = self._image_to_widget(self.selected_item.x, self.selected_item.y)
            dx = pos.x() - center.x()
            dy = pos.y() - center.y()
            current_angle = math.atan2(dy, dx)
            
            delta_angle = math.degrees(current_angle - self.drag_start.x())
            self.selected_item.angle = (self.rotation_start_angle + delta_angle) % 360
            
            self.furniture_rotated.emit(self.selected_item)
            self.update()
        
        elif event.buttons() == Qt.MiddleButton and self.drag_start:
            # Pan view
            delta = pos - self.drag_start
            self.pan_offset += delta
            self.drag_start = pos
            self.update()
        
        else:
            # Update hover state
            old_hover = self.hover_item
            self.hover_item = self._get_item_at(pos)
            
            # Update cursor
            if self.selected_item and self._is_on_rotation_handle(pos, self.selected_item):
                self.setCursor(Qt.CrossCursor)
            elif self.hover_item:
                self.setCursor(Qt.OpenHandCursor)
            else:
                self.setCursor(Qt.ArrowCursor)
            
            if old_hover != self.hover_item:
                self.update()
    
    def mouseReleaseEvent(self, event):
        """Handle mouse release events."""
        if event.button() == Qt.LeftButton:
            self.dragging = False
            self.rotating = False
            self.drag_start = None
            self.item_start_pos = None
            
            if self.hover_item:
                self.setCursor(Qt.OpenHandCursor)
            else:
                self.setCursor(Qt.ArrowCursor)
            
            self.canvas_updated.emit()
        
        elif event.button() == Qt.MiddleButton:
            self.drag_start = None
            self.setCursor(Qt.ArrowCursor)
    
    def wheelEvent(self, event):
        """Handle mouse wheel events."""
        modifiers = event.modifiers()
        
        if modifiers == Qt.ControlModifier:
            # Zoom
            delta = event.angleDelta().y()
            zoom_factor = 1.1 if delta > 0 else 0.9
            
            # Get mouse position in image coordinates before zoom
            mouse_pos = QPointF(event.pos())
            old_img_pos = self._widget_to_image(mouse_pos)
            
            # Apply zoom
            self.zoom_level *= zoom_factor
            self.zoom_level = max(0.1, min(5.0, self.zoom_level))
            
            # Adjust pan to keep mouse position stable
            new_widget_pos = self._image_to_widget(old_img_pos.x(), old_img_pos.y())
            self.pan_offset += mouse_pos - new_widget_pos
            
            self.update()
        
        elif self.selected_item:
            # Rotate selected item
            delta = event.angleDelta().y()
            rotation_step = 5 if delta > 0 else -5
            
            if modifiers == Qt.ShiftModifier:
                rotation_step = 15 if delta > 0 else -15  # Larger steps with Shift
            
            self.selected_item.rotate_by(rotation_step)
            self.furniture_rotated.emit(self.selected_item)
            self.update()
    
    def keyPressEvent(self, event):
        """Handle key press events."""
        if self.selected_item:
            step = 5
            if event.modifiers() == Qt.ShiftModifier:
                step = 1  # Fine movement
            
            if event.key() == Qt.Key_Left:
                self.selected_item.move_by(-step, 0)
            elif event.key() == Qt.Key_Right:
                self.selected_item.move_by(step, 0)
            elif event.key() == Qt.Key_Up:
                self.selected_item.move_by(0, -step)
            elif event.key() == Qt.Key_Down:
                self.selected_item.move_by(0, step)
            elif event.key() == Qt.Key_Delete:
                self.remove_furniture_item(self.selected_item)
                return
            elif event.key() == Qt.Key_R:
                self.selected_item.rotate_by(15)
            elif event.key() == Qt.Key_E:
                self.selected_item.rotate_by(-15)
            else:
                super().keyPressEvent(event)
                return
            
            self.furniture_moved.emit(self.selected_item)
            self.canvas_updated.emit()
            self.update()
        else:
            super().keyPressEvent(event)
    
    def _show_context_menu(self, pos):
        """Show context menu."""
        item = self._get_item_at(QPointF(pos))
        
        menu = QMenu(self)
        
        if item:
            self.selected_item = item
            self.furniture_selected.emit(item)
            self.update()
            
            # Item-specific actions
            delete_action = QAction(f"Delete {item.class_name}", self)
            delete_action.triggered.connect(lambda: self.remove_furniture_item(item))
            menu.addAction(delete_action)
            
            reset_rotation = QAction("Reset Rotation", self)
            reset_rotation.triggered.connect(lambda: self._reset_item_rotation(item))
            menu.addAction(reset_rotation)
            
            menu.addSeparator()
        
        # View actions
        toggle_labels = QAction("Show Labels" if not self.show_labels else "Hide Labels", self)
        toggle_labels.triggered.connect(self._toggle_labels)
        menu.addAction(toggle_labels)
        
        toggle_bboxes = QAction("Show Boxes" if not self.show_bboxes else "Hide Boxes", self)
        toggle_bboxes.triggered.connect(self._toggle_bboxes)
        menu.addAction(toggle_bboxes)
        
        menu.addSeparator()
        
        reset_view = QAction("Reset View", self)
        reset_view.triggered.connect(self._reset_view)
        menu.addAction(reset_view)
        
        menu.exec_(self.mapToGlobal(pos))
    
    def _reset_item_rotation(self, item: FurnitureItem):
        """Reset item rotation to 0."""
        item.angle = 0
        self.furniture_rotated.emit(item)
        self.update()
    
    def _toggle_labels(self):
        """Toggle label visibility."""
        self.show_labels = not self.show_labels
        self.update()
    
    def _toggle_bboxes(self):
        """Toggle bounding box visibility."""
        self.show_bboxes = not self.show_bboxes
        self.update()
    
    def _reset_view(self):
        """Reset zoom and pan."""
        self.zoom_level = 1.0
        self.pan_offset = QPointF(0, 0)
        self.update()
    
    def get_result_image(self) -> np.ndarray:
        """Generate the result image with furniture at current positions."""
        if self.floor_plan is None:
            return None
        
        # Use masked floor plan as base (furniture removed from original positions)
        result = self.floor_plan_masked.copy() if self.floor_plan_masked is not None else self.floor_plan.copy()
        
        for item in self.furniture_items:
            self._draw_furniture_on_image(result, item)
        
        return result
    
    def _draw_furniture_on_image(self, image: np.ndarray, item: FurnitureItem):
        """Draw furniture on the result image."""
        if item.image is None and item.icon is None:
            return
        
        src_img = item.icon if item.icon is not None else item.image
        
        # Resize to match item dimensions
        target_w = int(item.width)
        target_h = int(item.height)
        
        if target_w <= 0 or target_h <= 0:
            return
        
        resized = cv2.resize(src_img, (target_w, target_h))
        
        # Rotate if needed
        if item.angle != 0:
            center = (target_w / 2, target_h / 2)
            rotation_matrix = cv2.getRotationMatrix2D(center, -item.angle, 1.0)
            
            # Calculate new dimensions
            cos = abs(rotation_matrix[0, 0])
            sin = abs(rotation_matrix[0, 1])
            new_w = int(target_h * sin + target_w * cos)
            new_h = int(target_h * cos + target_w * sin)
            
            rotation_matrix[0, 2] += (new_w - target_w) / 2
            rotation_matrix[1, 2] += (new_h - target_h) / 2
            
            resized = cv2.warpAffine(resized, rotation_matrix, (new_w, new_h),
                                      borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0, 0))
        
        # Calculate position
        h, w = resized.shape[:2]
        x1 = int(item.x - w / 2)
        y1 = int(item.y - h / 2)
        x2 = x1 + w
        y2 = y1 + h
        
        # Clip to image bounds
        img_h, img_w = image.shape[:2]
        
        src_x1 = max(0, -x1)
        src_y1 = max(0, -y1)
        src_x2 = min(w, img_w - x1)
        src_y2 = min(h, img_h - y1)
        
        dst_x1 = max(0, x1)
        dst_y1 = max(0, y1)
        dst_x2 = min(img_w, x2)
        dst_y2 = min(img_h, y2)
        
        if dst_x2 <= dst_x1 or dst_y2 <= dst_y1:
            return
        
        # Blend with alpha if available
        if len(resized.shape) == 3 and resized.shape[2] == 4:
            alpha = resized[src_y1:src_y2, src_x1:src_x2, 3:4] / 255.0
            rgb = resized[src_y1:src_y2, src_x1:src_x2, :3]
            
            dst_region = image[dst_y1:dst_y2, dst_x1:dst_x2]
            blended = (rgb * alpha + dst_region * (1 - alpha)).astype(np.uint8)
            image[dst_y1:dst_y2, dst_x1:dst_x2] = blended
        else:
            image[dst_y1:dst_y2, dst_x1:dst_x2] = resized[src_y1:src_y2, src_x1:src_x2]
    
    def fit_to_view(self):
        """Fit the floor plan to the view."""
        if self.floor_plan is None:
            return
        
        img_w, img_h = self.original_size
        view_w, view_h = self.width(), self.height()
        
        # Calculate zoom to fit
        zoom_w = view_w / img_w
        zoom_h = view_h / img_h
        self.zoom_level = min(zoom_w, zoom_h) * 0.95
        
        # Center the image
        scaled_w = img_w * self.zoom_level
        scaled_h = img_h * self.zoom_level
        self.pan_offset = QPointF(
            (view_w - scaled_w) / 2,
            (view_h - scaled_h) / 2
        )
        
        self.update()
