"""
Main Window
Primary application window for the Floor Plan Manual Correction App.
"""

import os
import json
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QMenuBar, QMenu, QAction, QToolBar, QStatusBar,
    QFileDialog, QMessageBox, QSplitter, QScrollArea,
    QLabel, QPushButton, QGroupBox, QGridLayout,
    QDockWidget, QProgressBar, QSlider, QDoubleSpinBox,
    QComboBox, QCheckBox, QInputDialog
)
from PyQt5.QtCore import Qt, QSize, QTimer
from PyQt5.QtGui import QIcon, QPixmap, QImage, QKeySequence

from detection.yolo_detector import YOLODetector, MockYOLODetector
from detection.roboflow_detector import RoboflowDetector, MockRoboflowDetector
from detection.furniture_item import FurnitureItem
from .floor_plan_canvas import FloorPlanCanvas
from .properties_panel import PropertiesPanel
from .furniture_widget import FurnitureWidget


class MainWindow(QMainWindow):
    """Main application window."""
    
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle("Floor Plan Manual Correction")
        self.setMinimumSize(1200, 800)
        
        # State
        self.current_image_path = None
        self.detector = None
        self.furniture_items: list = []
        
        # Roboflow API settings
        self.roboflow_api_key = "bngHGPb2UJDgzZlQGaTu"  # Default key
        self.roboflow_model_id = "furniture-ya4pe/1"    # Default model
        
        # Initialize detector (Roboflow by default)
        self._init_roboflow_detector()
        
        # Setup UI
        self._setup_ui()
        self._setup_menus()
        self._setup_toolbar()
        self._setup_statusbar()
        self._setup_connections()
        
        # Apply dark theme
        self._apply_theme()
    
    def _init_roboflow_detector(self):
        """Initialize Roboflow detector."""
        try:
            self.detector = RoboflowDetector(
                api_key=self.roboflow_api_key,
                model_id=self.roboflow_model_id
            )
            self.using_roboflow = True
        except Exception as e:
            print(f"Could not initialize Roboflow detector: {e}")
            print("Using mock detector instead.")
            self.detector = MockRoboflowDetector()
            self.using_roboflow = False
        
        # Setup UI
        self._setup_ui()
        self._setup_menus()
        self._setup_toolbar()
        self._setup_statusbar()
        self._setup_connections()
        
        # Apply dark theme
        self._apply_theme()
    
    def _setup_ui(self):
        """Setup the main UI layout."""
        # Central widget with splitter
        central = QWidget()
        self.setCentralWidget(central)
        
        main_layout = QHBoxLayout(central)
        main_layout.setContentsMargins(5, 5, 5, 5)
        main_layout.setSpacing(5)
        
        # Main splitter
        self.splitter = QSplitter(Qt.Horizontal)
        main_layout.addWidget(self.splitter)
        
        # Left panel - Furniture catalog
        left_panel = self._create_catalog_panel()
        self.splitter.addWidget(left_panel)
        
        # Center - Floor plan canvas
        self.canvas = FloorPlanCanvas()
        self.splitter.addWidget(self.canvas)
        
        # Right panel - Properties
        self.properties_panel = PropertiesPanel()
        self.properties_panel.setMinimumWidth(250)
        self.properties_panel.setMaximumWidth(350)
        self.splitter.addWidget(self.properties_panel)
        
        # Set splitter sizes
        self.splitter.setSizes([200, 700, 300])
    
    def _create_catalog_panel(self) -> QWidget:
        """Create the furniture catalog panel."""
        panel = QWidget()
        panel.setMinimumWidth(150)
        panel.setMaximumWidth(250)
        
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(5, 5, 5, 5)
        
        # Title
        title = QLabel("Furniture Catalog")
        title.setStyleSheet("font-size: 14px; font-weight: bold;")
        layout.addWidget(title)
        
        # Catalog scroll area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        
        catalog_widget = QWidget()
        self.catalog_layout = QGridLayout(catalog_widget)
        self.catalog_layout.setSpacing(5)
        
        # Default furniture types
        furniture_types = [
            'bed', 'sofa', 'Lsofa', 'chair', 'table', 'desk',
            'cabinet', 'wardrobe', 'tv', 'lamp', 'bathtub',
            'toilet', 'sink', 'stove', 'dining_table', 'kitchen'
        ]
        
        row, col = 0, 0
        for ftype in furniture_types:
            widget = FurnitureWidget(ftype)
            widget.clicked.connect(self._on_catalog_item_clicked)
            self.catalog_layout.addWidget(widget, row, col)
            col += 1
            if col >= 2:
                col = 0
                row += 1
        
        scroll.setWidget(catalog_widget)
        layout.addWidget(scroll)
        
        return panel
    
    def _setup_menus(self):
        """Setup menu bar."""
        menubar = self.menuBar()
        
        # File menu
        file_menu = menubar.addMenu("&File")
        
        open_action = QAction("&Open Floor Plan...", self)
        open_action.setShortcut(QKeySequence.Open)
        open_action.triggered.connect(self._open_floor_plan)
        file_menu.addAction(open_action)
        
        file_menu.addSeparator()
        
        save_action = QAction("&Save Result...", self)
        save_action.setShortcut(QKeySequence.Save)
        save_action.triggered.connect(self._save_result)
        file_menu.addAction(save_action)
        
        export_json_action = QAction("Export &Layout (JSON)...", self)
        export_json_action.triggered.connect(self._export_layout_json)
        file_menu.addAction(export_json_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction("E&xit", self)
        exit_action.setShortcut(QKeySequence.Quit)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # Model menu
        model_menu = menubar.addMenu("&Model")
        
        # Roboflow submenu
        roboflow_menu = model_menu.addMenu("&Roboflow API")
        
        config_api_action = QAction("&Configure API Key...", self)
        config_api_action.triggered.connect(self._configure_roboflow_api)
        roboflow_menu.addAction(config_api_action)
        
        config_model_action = QAction("Set &Model ID...", self)
        config_model_action.triggered.connect(self._configure_roboflow_model)
        roboflow_menu.addAction(config_model_action)
        
        model_menu.addSeparator()
        
        load_model_action = QAction("&Load Local YOLO Model...", self)
        load_model_action.triggered.connect(self._load_yolo_model)
        model_menu.addAction(load_model_action)
        
        model_menu.addSeparator()
        
        self.use_mock_action = QAction("Use &Mock Detector", self)
        self.use_mock_action.setCheckable(True)
        self.use_mock_action.setChecked(not self.using_roboflow if hasattr(self, 'using_roboflow') else True)
        self.use_mock_action.triggered.connect(self._toggle_mock_detector)
        model_menu.addAction(self.use_mock_action)
        
        # Detection menu
        detect_menu = menubar.addMenu("&Detection")
        
        detect_action = QAction("&Detect Furniture", self)
        detect_action.setShortcut("Ctrl+D")
        detect_action.triggered.connect(self._run_detection)
        detect_menu.addAction(detect_action)
        
        detect_menu.addSeparator()
        
        # Confidence threshold submenu
        conf_menu = detect_menu.addMenu("Confidence Threshold")
        for conf in [0.1, 0.25, 0.5, 0.75]:
            action = QAction(f"{conf:.0%}", self)
            action.triggered.connect(lambda checked, c=conf: self._set_confidence(c))
            conf_menu.addAction(action)
        
        # View menu
        view_menu = menubar.addMenu("&View")
        
        fit_view_action = QAction("&Fit to View", self)
        fit_view_action.setShortcut("Ctrl+0")
        fit_view_action.triggered.connect(self.canvas.fit_to_view)
        view_menu.addAction(fit_view_action)
        
        view_menu.addSeparator()
        
        self.show_labels_action = QAction("Show &Labels", self)
        self.show_labels_action.setCheckable(True)
        self.show_labels_action.setChecked(True)
        self.show_labels_action.triggered.connect(self._toggle_labels)
        view_menu.addAction(self.show_labels_action)
        
        self.show_boxes_action = QAction("Show &Bounding Boxes", self)
        self.show_boxes_action.setCheckable(True)
        self.show_boxes_action.setChecked(True)
        self.show_boxes_action.triggered.connect(self._toggle_boxes)
        view_menu.addAction(self.show_boxes_action)
        
        # Edit menu
        edit_menu = menubar.addMenu("&Edit")
        
        clear_action = QAction("&Clear All Furniture", self)
        clear_action.triggered.connect(self._clear_furniture)
        edit_menu.addAction(clear_action)
        
        reset_action = QAction("&Reset All Positions", self)
        reset_action.triggered.connect(self._reset_all_positions)
        edit_menu.addAction(reset_action)
        
        # Help menu
        help_menu = menubar.addMenu("&Help")
        
        shortcuts_action = QAction("&Keyboard Shortcuts", self)
        shortcuts_action.triggered.connect(self._show_shortcuts)
        help_menu.addAction(shortcuts_action)
        
        about_action = QAction("&About", self)
        about_action.triggered.connect(self._show_about)
        help_menu.addAction(about_action)
    
    def _setup_toolbar(self):
        """Setup toolbar."""
        toolbar = QToolBar("Main Toolbar")
        toolbar.setIconSize(QSize(24, 24))
        self.addToolBar(toolbar)
        
        # Open button
        open_btn = QPushButton("Open")
        open_btn.clicked.connect(self._open_floor_plan)
        toolbar.addWidget(open_btn)
        
        toolbar.addSeparator()
        
        # Detect button
        detect_btn = QPushButton("Detect")
        detect_btn.clicked.connect(self._run_detection)
        toolbar.addWidget(detect_btn)
        
        toolbar.addSeparator()
        
        # Confidence slider
        toolbar.addWidget(QLabel(" Conf: "))
        self.conf_slider = QSlider(Qt.Horizontal)
        self.conf_slider.setRange(1, 100)
        self.conf_slider.setValue(25)
        self.conf_slider.setMaximumWidth(100)
        self.conf_slider.valueChanged.connect(self._on_conf_slider_changed)
        toolbar.addWidget(self.conf_slider)
        
        self.conf_label = QLabel("25%")
        self.conf_label.setMinimumWidth(40)
        toolbar.addWidget(self.conf_label)
        
        toolbar.addSeparator()
        
        # Save button
        save_btn = QPushButton("Save")
        save_btn.clicked.connect(self._save_result)
        toolbar.addWidget(save_btn)
        
        toolbar.addSeparator()
        
        # View toggles
        self.labels_checkbox = QCheckBox("Labels")
        self.labels_checkbox.setChecked(True)
        self.labels_checkbox.stateChanged.connect(self._toggle_labels)
        toolbar.addWidget(self.labels_checkbox)
        
        self.boxes_checkbox = QCheckBox("Boxes")
        self.boxes_checkbox.setChecked(True)
        self.boxes_checkbox.stateChanged.connect(self._toggle_boxes)
        toolbar.addWidget(self.boxes_checkbox)
    
    def _setup_statusbar(self):
        """Setup status bar."""
        self.statusbar = QStatusBar()
        self.setStatusBar(self.statusbar)
        
        self.status_label = QLabel("Ready")
        self.statusbar.addWidget(self.status_label)
        
        self.items_label = QLabel("Items: 0")
        self.statusbar.addPermanentWidget(self.items_label)
        
        self.zoom_label = QLabel("Zoom: 100%")
        self.statusbar.addPermanentWidget(self.zoom_label)
    
    def _setup_connections(self):
        """Setup signal connections."""
        # Canvas signals
        self.canvas.furniture_selected.connect(self._on_furniture_selected)
        self.canvas.furniture_moved.connect(self._on_furniture_moved)
        self.canvas.furniture_rotated.connect(self._on_furniture_rotated)
        self.canvas.furniture_deleted.connect(self._on_furniture_deleted)
        self.canvas.canvas_updated.connect(self._update_status)
        
        # Properties panel signals
        self.properties_panel.property_changed.connect(self._on_property_changed)
        self.properties_panel.delete_requested.connect(self._on_delete_requested)
    
    def _apply_theme(self):
        """Apply dark theme."""
        self.setStyleSheet("""
            QMainWindow, QWidget {
                background-color: #2b2b2b;
                color: #ffffff;
            }
            QMenuBar {
                background-color: #3c3c3c;
            }
            QMenuBar::item:selected {
                background-color: #5c5c5c;
            }
            QMenu {
                background-color: #3c3c3c;
            }
            QMenu::item:selected {
                background-color: #5c5c5c;
            }
            QToolBar {
                background-color: #3c3c3c;
                border: none;
                spacing: 5px;
                padding: 5px;
            }
            QPushButton {
                background-color: #4a4a4a;
                border: 1px solid #5c5c5c;
                padding: 5px 15px;
                border-radius: 3px;
            }
            QPushButton:hover {
                background-color: #5a5a5a;
            }
            QPushButton:pressed {
                background-color: #3a3a3a;
            }
            QGroupBox {
                border: 1px solid #5c5c5c;
                border-radius: 5px;
                margin-top: 10px;
                padding-top: 10px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
            }
            QSpinBox, QDoubleSpinBox, QLineEdit {
                background-color: #3c3c3c;
                border: 1px solid #5c5c5c;
                padding: 3px;
                border-radius: 3px;
            }
            QSlider::groove:horizontal {
                height: 6px;
                background: #4a4a4a;
                border-radius: 3px;
            }
            QSlider::handle:horizontal {
                width: 14px;
                height: 14px;
                background: #888;
                border-radius: 7px;
                margin: -4px 0;
            }
            QSlider::handle:horizontal:hover {
                background: #aaa;
            }
            QScrollBar:vertical {
                background: #2b2b2b;
                width: 12px;
            }
            QScrollBar::handle:vertical {
                background: #5c5c5c;
                border-radius: 6px;
                min-height: 20px;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0;
            }
            QStatusBar {
                background-color: #3c3c3c;
            }
            QSplitter::handle {
                background-color: #4a4a4a;
            }
            QCheckBox {
                spacing: 5px;
            }
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
            }
        """)
    
    # ================== Actions ==================
    
    def _open_floor_plan(self):
        """Open a floor plan image."""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Open Floor Plan",
            "",
            "Images (*.png *.jpg *.jpeg *.bmp *.tiff);;All Files (*)"
        )
        
        if file_path:
            self._load_floor_plan(file_path)
    
    def _load_floor_plan(self, file_path: str):
        """Load a floor plan image."""
        try:
            image = cv2.imread(file_path)
            if image is None:
                raise ValueError("Could not load image")
            
            self.current_image_path = file_path
            self.canvas.set_floor_plan(image)
            self.canvas.clear_furniture()
            self.canvas.fit_to_view()
            
            self.status_label.setText(f"Loaded: {Path(file_path).name}")
            self._update_status()
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load image: {e}")
    
    def _load_yolo_model(self):
        """Load a custom YOLO model."""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Load YOLO Model",
            "",
            "Model Files (*.pt *.onnx *.engine);;All Files (*)"
        )
        
        if file_path:
            try:
                self.detector = YOLODetector(model_path=file_path)
                self.use_mock_action.setChecked(False)
                self.using_roboflow = False
                self.status_label.setText(f"Model loaded: {Path(file_path).name}")
                QMessageBox.information(self, "Success", "YOLO model loaded successfully!")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to load model: {e}")
    
    def _configure_roboflow_api(self):
        """Configure Roboflow API key."""
        api_key, ok = QInputDialog.getText(
            self,
            "Roboflow API Key",
            "Enter your Roboflow API key:",
            text=self.roboflow_api_key or ""
        )
        
        if ok and api_key:
            self.roboflow_api_key = api_key
            try:
                self.detector = RoboflowDetector(
                    api_key=self.roboflow_api_key,
                    model_id=self.roboflow_model_id
                )
                self.using_roboflow = True
                self.use_mock_action.setChecked(False)
                self.status_label.setText("Roboflow API configured")
                QMessageBox.information(self, "Success", "Roboflow API key set successfully!")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to configure Roboflow: {e}")
    
    def _configure_roboflow_model(self):
        """Configure Roboflow model ID."""
        model_id, ok = QInputDialog.getText(
            self,
            "Roboflow Model ID",
            "Enter model ID (format: project/version):",
            text=self.roboflow_model_id or "furniture-ya4pe/1"
        )
        
        if ok and model_id:
            self.roboflow_model_id = model_id
            if self.using_roboflow and self.detector:
                self.detector.set_model(model_id)
                self.status_label.setText(f"Model ID set: {model_id}")
    
    def _toggle_mock_detector(self, checked: bool):
        """Toggle between mock and real detector."""
        if checked:
            self.detector = MockRoboflowDetector()
            self.using_roboflow = False
            self.status_label.setText("Using mock detector")
    
    def _run_detection(self):
        """Run furniture detection on the current image."""
        if self.canvas.floor_plan is None:
            QMessageBox.warning(self, "Warning", "Please load a floor plan first.")
            return
        
        try:
            self.status_label.setText("Detecting furniture...")
            self.statusbar.repaint()
            
            # Run detection
            conf = self.conf_slider.value() / 100.0
            self.detector.set_thresholds(confidence=conf)
            
            items = self.detector.detect(self.canvas.floor_plan, extract_crops=True)
            
            # Update canvas
            self.canvas.set_furniture_items(items)
            self.furniture_items = items
            
            self.status_label.setText(f"Detected {len(items)} furniture items")
            self._update_status()
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Detection failed: {e}")
            self.status_label.setText("Detection failed")
    
    def _set_confidence(self, conf: float):
        """Set confidence threshold."""
        self.conf_slider.setValue(int(conf * 100))
    
    def _on_conf_slider_changed(self, value: int):
        """Handle confidence slider change."""
        self.conf_label.setText(f"{value}%")
    
    def _save_result(self):
        """Save the result image."""
        if self.canvas.floor_plan is None:
            QMessageBox.warning(self, "Warning", "No floor plan loaded.")
            return
        
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Result",
            "",
            "PNG (*.png);;JPEG (*.jpg);;All Files (*)"
        )
        
        if file_path:
            try:
                result = self.canvas.get_result_image()
                cv2.imwrite(file_path, result)
                self.status_label.setText(f"Saved: {Path(file_path).name}")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to save: {e}")
    
    def _export_layout_json(self):
        """Export furniture layout as JSON."""
        if not self.canvas.furniture_items:
            QMessageBox.warning(self, "Warning", "No furniture items to export.")
            return
        
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Export Layout",
            "",
            "JSON (*.json);;All Files (*)"
        )
        
        if file_path:
            try:
                layout = {
                    'image_path': self.current_image_path,
                    'items': [item.to_dict() for item in self.canvas.furniture_items]
                }
                
                with open(file_path, 'w') as f:
                    json.dump(layout, f, indent=2)
                
                self.status_label.setText(f"Exported: {Path(file_path).name}")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to export: {e}")
    
    def _toggle_labels(self, state=None):
        """Toggle label visibility."""
        if isinstance(state, bool):
            self.canvas.show_labels = state
        else:
            self.canvas.show_labels = not self.canvas.show_labels
        
        self.labels_checkbox.blockSignals(True)
        self.labels_checkbox.setChecked(self.canvas.show_labels)
        self.labels_checkbox.blockSignals(False)
        
        self.show_labels_action.blockSignals(True)
        self.show_labels_action.setChecked(self.canvas.show_labels)
        self.show_labels_action.blockSignals(False)
        
        self.canvas.update()
    
    def _toggle_boxes(self, state=None):
        """Toggle bounding box visibility."""
        if isinstance(state, bool):
            self.canvas.show_bboxes = state
        else:
            self.canvas.show_bboxes = not self.canvas.show_bboxes
        
        self.boxes_checkbox.blockSignals(True)
        self.boxes_checkbox.setChecked(self.canvas.show_bboxes)
        self.boxes_checkbox.blockSignals(False)
        
        self.show_boxes_action.blockSignals(True)
        self.show_boxes_action.setChecked(self.canvas.show_bboxes)
        self.show_boxes_action.blockSignals(False)
        
        self.canvas.update()
    
    def _clear_furniture(self):
        """Clear all furniture items."""
        if self.canvas.furniture_items:
            reply = QMessageBox.question(
                self, "Confirm",
                "Clear all furniture items?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply == QMessageBox.Yes:
                self.canvas.clear_furniture()
                self._update_status()
    
    def _reset_all_positions(self):
        """Reset all furniture to original positions."""
        for item in self.canvas.furniture_items:
            if item.original_bbox:
                x1, y1, x2, y2 = item.original_bbox
                item.x = (x1 + x2) / 2
                item.y = (y1 + y2) / 2
                item.angle = 0
        
        self.canvas.update()
        self.properties_panel.update_from_item()
    
    def _show_shortcuts(self):
        """Show keyboard shortcuts dialog."""
        shortcuts = """
<h3>Keyboard Shortcuts</h3>
<table>
<tr><td><b>Ctrl+O</b></td><td>Open floor plan</td></tr>
<tr><td><b>Ctrl+S</b></td><td>Save result</td></tr>
<tr><td><b>Ctrl+D</b></td><td>Detect furniture</td></tr>
<tr><td><b>Ctrl+0</b></td><td>Fit to view</td></tr>
<tr><td><b>Arrow Keys</b></td><td>Move selected item</td></tr>
<tr><td><b>Shift+Arrow</b></td><td>Fine movement</td></tr>
<tr><td><b>R / E</b></td><td>Rotate selected item</td></tr>
<tr><td><b>Delete</b></td><td>Delete selected item</td></tr>
<tr><td><b>Mouse Wheel</b></td><td>Rotate selected item</td></tr>
<tr><td><b>Ctrl+Wheel</b></td><td>Zoom in/out</td></tr>
<tr><td><b>Middle Mouse</b></td><td>Pan view</td></tr>
</table>
"""
        QMessageBox.information(self, "Keyboard Shortcuts", shortcuts)
    
    def _show_about(self):
        """Show about dialog."""
        about_text = """
<h3>Floor Plan Manual Correction</h3>
<p>An application for manually correcting furniture placement in floor plans.</p>
<p><b>Features:</b></p>
<ul>
<li>YOLO-based furniture detection</li>
<li>Drag and drop furniture placement</li>
<li>Rotate and resize furniture</li>
<li>Export corrected layouts</li>
</ul>
<p>Supports custom YOLO models (plug-and-play)</p>
"""
        QMessageBox.about(self, "About", about_text)
    
    def _on_catalog_item_clicked(self, class_name: str):
        """Handle catalog item click."""
        self.status_label.setText(f"Selected: {class_name} (drag to add)")
    
    # ================== Signal Handlers ==================
    
    def _on_furniture_selected(self, item: FurnitureItem):
        """Handle furniture selection."""
        self.properties_panel.set_item(item)
        if item:
            self.status_label.setText(f"Selected: {item.class_name}")
    
    def _on_furniture_moved(self, item: FurnitureItem):
        """Handle furniture movement."""
        self.properties_panel.update_from_item()
    
    def _on_furniture_rotated(self, item: FurnitureItem):
        """Handle furniture rotation."""
        self.properties_panel.update_from_item()
    
    def _on_furniture_deleted(self, item: FurnitureItem):
        """Handle furniture deletion."""
        self.properties_panel.set_item(None)
        self._update_status()
    
    def _on_property_changed(self, item: FurnitureItem):
        """Handle property change from panel."""
        self.canvas.update()
    
    def _on_delete_requested(self, item: FurnitureItem):
        """Handle delete request from panel."""
        self.canvas.remove_furniture_item(item)
    
    def _update_status(self):
        """Update status bar."""
        count = len(self.canvas.furniture_items)
        self.items_label.setText(f"Items: {count}")
        self.zoom_label.setText(f"Zoom: {self.canvas.zoom_level:.0%}")
